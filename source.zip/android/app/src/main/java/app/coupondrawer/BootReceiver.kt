package app.coupondrawer

import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent

class BootReceiver : BroadcastReceiver() {
    override fun onReceive(c: Context, intent: Intent) {
        if (Prefs.autoDetect(c) && Perms.media(c)) ScanJobService.schedule(c)
        ExpiryWorker.schedule(c)
    }
}
