package app.coupondrawer

import com.google.android.gms.tasks.Tasks
import com.google.mlkit.vision.barcode.BarcodeScannerOptions
import com.google.mlkit.vision.barcode.BarcodeScanning
import com.google.mlkit.vision.barcode.common.Barcode
import com.google.mlkit.vision.common.InputImage
import com.google.mlkit.vision.text.TextRecognition
import com.google.mlkit.vision.text.korean.KoreanTextRecognizerOptions
import java.util.concurrent.TimeUnit

/** On-device recognition with Google ML Kit (bundled models, works offline). Call off the main thread. */
object Recognizer {
    private val barcodeClient by lazy {
        BarcodeScanning.getClient(
            BarcodeScannerOptions.Builder().setBarcodeFormats(
                Barcode.FORMAT_CODE_128, Barcode.FORMAT_EAN_13, Barcode.FORMAT_ITF,
                Barcode.FORMAT_CODE_39, Barcode.FORMAT_CODE_93, Barcode.FORMAT_CODABAR,
                Barcode.FORMAT_EAN_8, Barcode.FORMAT_QR_CODE
            ).build()
        )
    }
    private val textClient by lazy { TextRecognition.getClient(KoreanTextRecognizerOptions.Builder().build()) }
    private val codeRe = Regex("^[0-9A-Za-z]{8,30}$")

    fun barcode(img: InputImage): String {
        val found = Tasks.await(barcodeClient.process(img), 20, TimeUnit.SECONDS)
        val values = found.mapNotNull { b -> b.rawValue?.replace(Regex("[\\s-]"), "")?.let { Pair(b.format, it) } }
            .filter { codeRe.matches(it.second) }
        // prefer a linear barcode with digits; QR codes in gift images often hold a URL
        return (values.firstOrNull { it.first != Barcode.FORMAT_QR_CODE && it.second.count(Char::isDigit) >= 8 }
            ?: values.firstOrNull())?.second ?: ""
    }

    fun text(img: InputImage): String = Tasks.await(textClient.process(img), 30, TimeUnit.SECONDS).text
}
