package app.coupondrawer

import android.Manifest
import android.content.Context
import android.content.pm.PackageManager
import android.os.Build
import androidx.core.content.ContextCompat

object Prefs {
    private fun p(c: Context) = c.getSharedPreferences("coupon", Context.MODE_PRIVATE)
    fun autoDetect(c: Context) = p(c).getBoolean("autoDetect", false)
    fun setAutoDetect(c: Context, on: Boolean) = p(c).edit().putBoolean("autoDetect", on).apply()
    fun lastScan(c: Context) = p(c).getLong("lastScan", 0L)
    fun setLastScan(c: Context, sec: Long) = p(c).edit().putLong("lastScan", sec).apply()
    fun alerts(c: Context) = p(c).getBoolean("alerts", true)
    fun setAlerts(c: Context, on: Boolean) = p(c).edit().putBoolean("alerts", on).apply()

    /** 알림을 보낼 시점(만료까지 남은 일수). 기본은 7일 전 · 3일 전 · 전날 · 당일. */
    fun alertDays(c: Context): Set<Int> =
        (p(c).getString("alertDays", "7,3,1,0") ?: "")
            .split(",").mapNotNull { it.trim().toIntOrNull() }.filter { it in 0..60 }.toSet()

    fun setAlertDays(c: Context, days: Set<Int>) =
        p(c).edit().putString("alertDays", days.sortedDescending().joinToString(",")).apply()

    /** 만료 알림을 보내는 시각(0~23). 기본 오전 9시. */
    fun alertHour(c: Context) = p(c).getInt("alertHour", 9).coerceIn(0, 23)
    fun seenIds(c: Context): MutableSet<String> = HashSet(p(c).getStringSet("seen", emptySet()) ?: emptySet())
    fun setSeenIds(c: Context, s: Set<String>) {
        // keep the newest ~600 media ids (ids grow monotonically)
        val trimmed = if (s.size > 600) s.sortedByDescending { it.toLongOrNull() ?: 0L }.take(600).toSet() else s
        p(c).edit().putStringSet("seen", trimmed).apply()
    }
    fun sentAlerts(c: Context): MutableSet<String> = HashSet(p(c).getStringSet("sent", emptySet()) ?: emptySet())
    fun setSentAlerts(c: Context, s: Set<String>) = p(c).edit().putStringSet("sent", s).apply()
}

object Perms {
    val mediaPermission: String
        get() = if (Build.VERSION.SDK_INT >= 33) Manifest.permission.READ_MEDIA_IMAGES else Manifest.permission.READ_EXTERNAL_STORAGE

    private fun granted(c: Context, p: String) = ContextCompat.checkSelfPermission(c, p) == PackageManager.PERMISSION_GRANTED
    fun media(c: Context) = granted(c, mediaPermission)
    fun notifications(c: Context) = Build.VERSION.SDK_INT < 33 || granted(c, Manifest.permission.POST_NOTIFICATIONS)
    fun forAutoDetect(): Array<String> =
        if (Build.VERSION.SDK_INT >= 33) arrayOf(mediaPermission, Manifest.permission.POST_NOTIFICATIONS) else arrayOf(mediaPermission)
}
