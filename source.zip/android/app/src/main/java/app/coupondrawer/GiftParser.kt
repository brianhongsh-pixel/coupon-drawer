package app.coupondrawer

/** Reads coupon fields out of OCR text. Kept in step with parseGift() in web/app.js. */
object GiftParser {
    data class Gift(
        var brand: String = "", var name: String = "", var barcode: String = "",
        var expiry: String = "", var type: String = "item", var amount: Long = 0
    )

    val BRANDS = listOf("스타벅스","투썸플레이스","투썸","이디야","메가MGC커피","메가커피","컴포즈커피","빽다방","할리스","폴바셋","커피빈","탐앤탐스","파스쿠찌","엔제리너스","공차","설빙","배스킨라빈스","던킨","크리스피크림","파리바게뜨","뚜레쥬르","성심당","맥도날드","버거킹","롯데리아","맘스터치","KFC","쉐이크쉑","서브웨이","BHC","BBQ","교촌치킨","교촌","굽네치킨","굽네","노랑통닭","처갓집","푸라닭","60계","네네치킨","도미노피자","피자헛","파파존스","미스터피자","피자스쿨","CU","GS25","세븐일레븐","이마트24","미니스톱","이마트","홈플러스","롯데마트","GS더프레시","올리브영","다이소","신세계","롯데백화점","현대백화점","갤러리아","배달의민족","배민","요기요","쿠팡이츠","컬리","CGV","메가박스","롯데시네마","교보문고","영풍문고","예스24","아웃백","빕스","VIPS","애슐리","본죽","죽이야기","한솥","김밥천국","구글플레이","Google Play","문화상품권","컬쳐랜드","해피머니","북앤라이프","스마일캐시","네이버페이","카카오페이")
    private val STOP = Regex("(유효기간|교환처|주문번호|쿠폰번호|사용기한|카카오톡|선물하기|kakao|gift|바코드|사용처|사용방법|유의사항|발행일|선물|gifticon|일시|상품권번호|인증번호|PIN)", RegexOption.IGNORE_CASE)
    private val FIXES = listOf(
        Regex("[6G][S5$]\\s?25") to "GS25",
        Regex("이마트\\s?2[4A]") to "이마트24",
        Regex("세븐\\s?일레븐") to "세븐일레븐"
    )
    private val DATE = Regex("(20\\d{2})\\s*[.\\-/년]\\s*(\\d{1,2})\\s*[.\\-/월]\\s*(\\d{1,2})")
    private val DATE_START = Regex("20\\d{2}\\s*[.\\-/년]")
    val COUPON_WORDS = Regex("(유효기간|교환처|쿠폰|상품권|기프티콘|선물|사용기한|교환권)")

    private fun squash(s: String) = s.replace(Regex("\\s+"), "")
    private fun fixName(s: String) = s.replace(Regex("(\\d)\\s*(7%|7H|7]|7\\})(?=\\s|$)"), "$1잔")
        .replace(Regex("[|_~]+"), " ").replace(Regex("\\s{2,}"), " ").trim()

    fun parse(raw: String): Gift {
        var text = raw.replace("\r", "")
        FIXES.forEach { (re, v) -> text = text.replace(re, v) }
        val lines = text.split("\n").map { it.trim() }.filter { it.isNotEmpty() }
        val flat = squash(text)
        val g = Gift()

        // expiry: a date on a 유효기간/까지 line wins, otherwise the latest date
        data class Cand(val iso: String, val pri: Int)
        val cands = ArrayList<Cand>()
        for (l in lines) for (m in DATE.findAll(l)) {
            val y = m.groupValues[1].toInt(); val mo = m.groupValues[2].toInt(); val d = m.groupValues[3].toInt()
            if (mo in 1..12 && d in 1..31) cands.add(Cand("%04d-%02d-%02d".format(y, mo, d), if (Regex("(유효|기한|까지|만료|~)").containsMatchIn(l)) 1 else 0))
        }
        cands.sortedWith(compareByDescending<Cand> { it.pri }.thenByDescending { it.iso }).firstOrNull()?.let { g.expiry = it.iso }

        // brand: known names first, then the "교환처" label
        val low = flat.lowercase()
        BRANDS.firstOrNull { low.contains(squash(it).lowercase()) }?.let {
            g.brand = when (it) { "투썸" -> "투썸플레이스"; "배민" -> "배달의민족"; else -> it }
        }
        if (g.brand.isEmpty()) {
            lines.firstOrNull { Regex("교환처|사용처").containsMatchIn(squash(it)) }?.let { l ->
                val v = l.replace(Regex(".*(교\\s*환\\s*처|사\\s*용\\s*처)\\s*[:：]?\\s*"), "").trim()
                if (v.isNotEmpty() && v.length <= 20 && Regex("[가-힣A-Za-z]").containsMatchIn(v)) g.brand = v
            }
        }

        // product name: "상품명" label, else the first meaningful Hangul line
        lines.firstOrNull { squash(it).contains("상품명") }?.let { l ->
            g.name = fixName(l.replace(Regex(".*상\\s*품\\s*명\\s*[:：]?\\s*"), ""))
        }
        if (g.name.isEmpty()) {
            lines.firstOrNull { l ->
                Regex("[가-힣]").findAll(l).count() >= 3 && !STOP.containsMatchIn(squash(l)) &&
                    !Regex("^\\d").containsMatchIn(l) && squash(l) != squash(g.brand) && !DATE_START.containsMatchIn(l)
            }?.let { g.name = fixName(it) }
        }

        // coupon number from text: longest 10–20 digit run
        Regex("\\d[\\d \\-]{9,28}\\d").findAll(text).map { it.value.replace(Regex("[ \\-]"), "") }
            .filter { it.length in 10..20 && !Regex("^20\\d{6}$").matches(it) }
            .maxByOrNull { it.length }?.let { g.barcode = it }

        // cash voucher
        if (Regex("(금액권|상품권|충전|잔액|원권|만원권)").containsMatchIn(flat)) {
            val m = Regex("(\\d{1,3}(?:,\\d{3})+|\\d{4,7})원").find(flat)
            val man = Regex("(\\d{1,2})만원").find(flat)
            if (m != null) { g.type = "cash"; g.amount = m.groupValues[1].replace(",", "").toLongOrNull() ?: 0 }
            else if (man != null) { g.type = "cash"; g.amount = (man.groupValues[1].toLongOrNull() ?: 0) * 10000 }
        }
        return g
    }
}
