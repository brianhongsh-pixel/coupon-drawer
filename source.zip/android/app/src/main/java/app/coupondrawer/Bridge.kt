package app.coupondrawer

import android.content.ClipData
import android.content.ClipboardManager
import android.content.Intent
import android.graphics.BitmapFactory
import android.net.Uri
import android.provider.CalendarContract
import android.provider.Settings
import android.util.Base64
import android.view.WindowManager
import android.webkit.JavascriptInterface
import android.widget.Toast
import androidx.core.content.FileProvider
import com.google.mlkit.vision.common.InputImage
import org.json.JSONObject
import java.io.File
import java.time.LocalDate
import java.time.ZoneId

/** Everything the web app can ask the phone to do. Exposed to JavaScript as window.CouponNative. */
class Bridge(private val a: MainActivity) {
    private var permCallback: String? = null

    private fun done(id: String, json: String) =
        a.js("window.__nativeDone(${JSONObject.quote(id)}, ${JSONObject.quote(json)})")

    @JavascriptInterface fun version(): String = BuildConfig.VERSION_NAME

    @JavascriptInterface
    fun status(): String = JSONObject()
        .put("autoDetect", Prefs.autoDetect(a) && Perms.media(a))
        .put("mediaPermission", Perms.media(a))
        .put("notifications", Perms.notifications(a))
        .put("alerts", Prefs.alerts(a))
        .put("lastScan", Prefs.lastScan(a))
        .put("version", BuildConfig.VERSION_NAME)
        .toString()

    /** Recognize an image the user picked inside the app. Answers {barcode, text}. */
    @JavascriptInterface
    fun recognize(id: String, b64: String) {
        Thread {
            val r = JSONObject()
            try {
                val bytes = Base64.decode(b64, Base64.DEFAULT)
                val bmp = BitmapFactory.decodeByteArray(bytes, 0, bytes.size)
                val img = InputImage.fromBitmap(bmp, 0)
                r.put("barcode", try { Recognizer.barcode(img) } catch (e: Exception) { "" })
                r.put("text", try { Recognizer.text(img) } catch (e: Exception) { "" })
            } catch (e: Throwable) {
                r.put("error", e.message ?: "error")
            }
            done(id, r.toString())
        }.start()
    }

    @JavascriptInterface fun takePending(): String = Store.takePending(a).toString()

    @JavascriptInterface fun pendingCount(): Int = Store.pendingCount(a)

    @JavascriptInterface fun syncCoupons(json: String) {
        Store.syncCoupons(a, json)
    }

    /** Turn automatic gallery detection on/off. Asks for photo + notification permission when needed. */
    @JavascriptInterface
    fun setAutoDetect(id: String, on: Boolean) {
        if (!on) {
            Prefs.setAutoDetect(a, false)
            ScanJobService.cancel(a)
            done(id, status()); return
        }
        Prefs.setAutoDetect(a, true)
        if (Perms.media(a) && Perms.notifications(a)) { onPermissionsResult(id); return }
        permCallback = id
        a.runOnUiThread { a.askPermissions.launch(Perms.forAutoDetect()) }
    }

    fun onPermissionsResult(id: String? = permCallback) {
        permCallback = null
        if (Perms.media(a) && Prefs.autoDetect(a)) {
            if (Prefs.lastScan(a) == 0L) Prefs.setLastScan(a, System.currentTimeMillis() / 1000)
            ScanJobService.schedule(a)
        }
        ExpiryWorker.schedule(a)
        if (id != null) done(id, status())
    }

    /** Look through photos from the last [days] days for coupons. Answers {count} or {error}. */
    @JavascriptInterface
    fun scanRecent(id: String, days: Int) {
        if (!Perms.media(a)) { done(id, JSONObject().put("error", "permission").toString()); return }
        Thread {
            val since = System.currentTimeMillis() / 1000 - days * 86400L
            val n = try { Scanner.scanNew(a.applicationContext, since, notify = false, limit = 400).size } catch (e: Throwable) { -1 }
            done(id, JSONObject().put("count", n).toString())
        }.start()
    }

    @JavascriptInterface fun setAlerts(on: Boolean) = Prefs.setAlerts(a, on)

    @JavascriptInterface
    fun openAppSettings() {
        a.runOnUiThread {
            try { a.startActivity(Intent(Settings.ACTION_APPLICATION_DETAILS_SETTINGS, Uri.parse("package:" + a.packageName))) } catch (_: Exception) {}
        }
    }

    private fun cacheFile(name: String): File = File(a.cacheDir, "out/$name").apply { parentFile?.mkdirs() }
    private fun uriFor(f: File): Uri = FileProvider.getUriForFile(a, a.packageName + ".files", f)

    @JavascriptInterface
    fun share(text: String, imageB64: String) {
        a.runOnUiThread {
            try {
                val i = Intent(Intent.ACTION_SEND).putExtra(Intent.EXTRA_TEXT, text)
                if (imageB64.isNotEmpty()) {
                    val f = cacheFile("coupon.jpg"); f.writeBytes(Base64.decode(imageB64, Base64.DEFAULT))
                    i.type = "image/jpeg"; i.putExtra(Intent.EXTRA_STREAM, uriFor(f)); i.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
                } else i.type = "text/plain"
                a.startActivity(Intent.createChooser(i, "쿠폰 보내기"))
            } catch (e: Exception) { toast("보낼 수 있는 앱이 없어요") }
        }
    }

    /** Hands a generated file (backup) to the share sheet so the user can save it to Drive, Files, etc. */
    @JavascriptInterface
    fun saveFile(name: String, mime: String, b64: String) {
        a.runOnUiThread {
            try {
                val f = cacheFile(name); f.writeBytes(Base64.decode(b64, Base64.DEFAULT))
                val i = Intent(Intent.ACTION_SEND).setType(mime).putExtra(Intent.EXTRA_STREAM, uriFor(f)).addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
                a.startActivity(Intent.createChooser(i, "백업 파일 저장"))
            } catch (e: Exception) { toast("파일을 저장하지 못했어요") }
        }
    }

    @JavascriptInterface
    fun copy(text: String) {
        a.runOnUiThread {
            a.getSystemService(ClipboardManager::class.java)?.setPrimaryClip(ClipData.newPlainText("쿠폰번호", text))
        }
    }

    @JavascriptInterface
    fun addCalendar(title: String, isoDate: String, description: String) {
        a.runOnUiThread {
            try {
                val start = LocalDate.parse(isoDate).atStartOfDay(ZoneId.systemDefault()).toInstant().toEpochMilli()
                val i = Intent(Intent.ACTION_INSERT).setData(CalendarContract.Events.CONTENT_URI)
                    .putExtra(CalendarContract.Events.TITLE, title)
                    .putExtra(CalendarContract.Events.DESCRIPTION, description)
                    .putExtra(CalendarContract.EXTRA_EVENT_ALL_DAY, true)
                    .putExtra(CalendarContract.EXTRA_EVENT_BEGIN_TIME, start)
                    .putExtra(CalendarContract.EXTRA_EVENT_END_TIME, start + 86_400_000L)
                a.startActivity(i)
            } catch (e: Exception) { toast("캘린더 앱을 열 수 없어요") }
        }
    }

    /** Full brightness and screen kept on while the barcode is shown to a cashier. */
    @JavascriptInterface
    fun barcodeMode(on: Boolean) {
        a.runOnUiThread {
            val lp = a.window.attributes
            lp.screenBrightness = if (on) 1f else WindowManager.LayoutParams.BRIGHTNESS_OVERRIDE_NONE
            a.window.attributes = lp
            if (on) a.window.addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON)
            else a.window.clearFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON)
        }
    }

    private fun toast(msg: String) = Toast.makeText(a, msg, Toast.LENGTH_SHORT).show()
}
