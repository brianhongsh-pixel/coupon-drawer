package app.coupondrawer

import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.content.Context
import android.content.Intent
import androidx.core.app.NotificationCompat
import androidx.core.app.NotificationManagerCompat
import org.json.JSONObject
import java.time.LocalDate
import java.time.temporal.ChronoUnit

object Notifier {
    private const val CH_AUTO = "auto"
    private const val CH_EXPIRY = "expiry"

    fun createChannels(c: Context) {
        val nm = c.getSystemService(NotificationManager::class.java) ?: return
        nm.createNotificationChannel(NotificationChannel(CH_AUTO, "자동 등록", NotificationManager.IMPORTANCE_DEFAULT).apply {
            description = "새 기프티콘을 찾아 등록했을 때"
        })
        nm.createNotificationChannel(NotificationChannel(CH_EXPIRY, "만료 알림", NotificationManager.IMPORTANCE_HIGH).apply {
            description = "유효기간이 다가온 기프티콘을 모아서 알려 줘요"
        })
    }

    private fun openApp(c: Context): PendingIntent =
        PendingIntent.getActivity(
            c, 0, Intent(c, MainActivity::class.java).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_SINGLE_TOP),
            PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT
        )

    private fun post(c: Context, id: Int, channel: String, title: String, body: String) {
        if (!Perms.notifications(c)) return
        val n = NotificationCompat.Builder(c, channel)
            .setSmallIcon(R.drawable.ic_stat_coupon)
            .setColor(0xFF0E6E55.toInt())
            .setContentTitle(title)
            .setContentText(body)
            .setStyle(NotificationCompat.BigTextStyle().bigText(body))
            .setContentIntent(openApp(c))
            .setAutoCancel(true)
            .build()
        try { NotificationManagerCompat.from(c).notify(id, n) } catch (_: SecurityException) {}
    }

    private fun daysLeft(expiry: String): Long? = try {
        ChronoUnit.DAYS.between(LocalDate.now(), LocalDate.parse(expiry))
    } catch (e: Exception) { null }

    private fun label(o: JSONObject): String {
        val brand = o.optString("brand"); val name = o.optString("name")
        return listOf(brand, name).filter { it.isNotEmpty() }.joinToString(" ")
    }

    fun imported(c: Context, list: List<JSONObject>) {
        val title = if (list.size == 1) "기프티콘을 자동 등록했어요" else "기프티콘 ${list.size}개를 자동 등록했어요"
        val body = list.joinToString("\n") { o ->
            val d = daysLeft(o.optString("expiry"))
            label(o) + (if (d != null) " · D-$d" else "") + (if (o.optBoolean("needsReview")) " (확인 필요)" else "")
        }
        post(c, 1001, CH_AUTO, title, body)
    }

    fun checkExpiry(c: Context) {
        if (!Prefs.alerts(c)) return
        val days = Prefs.alertDays(c)
        if (days.isEmpty()) return
        val sent = Prefs.sentAlerts(c)
        // 같은 시점에 만료되는 쿠폰은 알림 하나로 묶어요.
        val byDay = HashMap<Int, MutableList<JSONObject>>()
        for (o in Store.allCoupons(c)) {
            if (o.optBoolean("used")) continue
            val d = daysLeft(o.optString("expiry")) ?: continue
            if (d < 0 || d > 60 || d.toInt() !in days) continue
            if (o.optString("id") + ":" + d in sent) continue
            byDay.getOrPut(d.toInt()) { ArrayList() }.add(o)
        }
        for (d in byDay.keys.sorted()) {
            val list = byDay[d] ?: continue
            if (list.isEmpty()) continue
            val whenText = when (d) {
                0 -> "오늘 만료돼요"
                1 -> "내일 만료돼요"
                else -> "${d}일 뒤 만료돼요"
            }
            val title = if (list.size == 1) "${list[0].optString("brand").ifEmpty { "기프티콘" }} $whenText"
            else "쿠폰 ${list.size}개가 $whenText"
            val body = list.take(5).joinToString("\n") { o ->
                "· " + label(o) + " (" + o.optString("expiry").replace("-", ".") + "까지)"
            } + if (list.size > 5) "\n외 ${list.size - 5}개" else ""
            post(c, 2000 + d, CH_EXPIRY, title, body)
            list.forEach { sent.add(it.optString("id") + ":" + d) }
        }
        // 보낸 기록이 너무 커지면 비워요.
        if (sent.size > 800) sent.clear()
        Prefs.setSentAlerts(c, sent)
    }
}
