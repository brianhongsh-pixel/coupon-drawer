package app.coupondrawer

import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.content.Context
import android.content.Intent
import androidx.core.app.NotificationCompat
import androidx.core.app.NotificationManagerCompat
import org.json.JSONObject
import java.time.LocalDate
import java.time.temporal.ChronoUnit

object Notifier {
    private const val CH_AUTO = "auto"
    private const val CH_EXPIRY = "expiry"

    fun createChannels(c: Context) {
        val nm = c.getSystemService(NotificationManager::class.java) ?: return
        nm.createNotificationChannel(NotificationChannel(CH_AUTO, "자동 등록", NotificationManager.IMPORTANCE_DEFAULT).apply {
            description = "새 기프티콘을 찾아 등록했을 때"
        })
        nm.createNotificationChannel(NotificationChannel(CH_EXPIRY, "만료 알림", NotificationManager.IMPORTANCE_HIGH).apply {
            description = "기프티콘 만료 3일 전, 전날, 당일"
        })
    }

    private fun openApp(c: Context): PendingIntent =
        PendingIntent.getActivity(
            c, 0, Intent(c, MainActivity::class.java).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_SINGLE_TOP),
            PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT
        )

    private fun post(c: Context, id: Int, channel: String, title: String, body: String) {
        if (!Perms.notifications(c)) return
        val n = NotificationCompat.Builder(c, channel)
            .setSmallIcon(R.drawable.ic_stat_coupon)
            .setColor(0xFF0E6E55.toInt())
            .setContentTitle(title)
            .setContentText(body)
            .setStyle(NotificationCompat.BigTextStyle().bigText(body))
            .setContentIntent(openApp(c))
            .setAutoCancel(true)
            .build()
        try { NotificationManagerCompat.from(c).notify(id, n) } catch (_: SecurityException) {}
    }

    private fun daysLeft(expiry: String): Long? = try {
        ChronoUnit.DAYS.between(LocalDate.now(), LocalDate.parse(expiry))
    } catch (e: Exception) { null }

    private fun label(o: JSONObject): String {
        val brand = o.optString("brand"); val name = o.optString("name")
        return listOf(brand, name).filter { it.isNotEmpty() }.joinToString(" ")
    }

    fun imported(c: Context, list: List<JSONObject>) {
        val title = if (list.size == 1) "기프티콘을 자동 등록했어요" else "기프티콘 ${list.size}개를 자동 등록했어요"
        val body = list.joinToString("\n") { o ->
            val d = daysLeft(o.optString("expiry"))
            label(o) + (if (d != null) " · D-$d" else "") + (if (o.optBoolean("needsReview")) " (확인 필요)" else "")
        }
        post(c, 1001, CH_AUTO, title, body)
    }

    fun checkExpiry(c: Context) {
        if (!Prefs.alerts(c)) return
        val sent = Prefs.sentAlerts(c)
        var n = 0
        for (o in Store.allCoupons(c)) {
            if (o.optBoolean("used")) continue
            val d = daysLeft(o.optString("expiry")) ?: continue
            if (d != 0L && d != 1L && d != 3L) continue
            val key = o.optString("id") + ":" + d
            if (key in sent) continue
            val title = when (d) { 0L -> "오늘 만료돼요"; 1L -> "내일 만료돼요"; else -> "3일 뒤 만료돼요" }
            post(c, 2000 + (o.optString("id").hashCode() and 0xfff), CH_EXPIRY, "${o.optString("brand").ifEmpty { "기프티콘" }} $title",
                "${o.optString("name")} · ${o.optString("expiry").replace("-", ".")}까지")
            sent.add(key); n++
        }
        // forget keys older than a few weeks so the set stays small
        if (sent.size > 400) sent.clear()
        if (n > 0 || sent.isNotEmpty()) Prefs.setSentAlerts(c, sent)
    }
}
