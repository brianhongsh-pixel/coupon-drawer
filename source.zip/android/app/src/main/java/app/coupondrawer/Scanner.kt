package app.coupondrawer

import android.content.ContentUris
import android.content.Context
import android.net.Uri
import android.os.Build
import android.provider.MediaStore
import com.google.mlkit.vision.common.InputImage
import org.json.JSONObject
import java.io.File
import java.util.UUID

/** Finds coupon images and queues them for the app. */
object Scanner {
    enum class Outcome { ADDED, DUPLICATE, NOT_COUPON, FAILED }
    data class Result(val outcome: Outcome, val coupon: JSONObject? = null)

    private val hintedPath = Regex("(?i)(screenshot|스크린샷|kakao|카카오|download|다운로드|gift|쿠폰|coupon|기프티)")

    /**
     * Recognizes one image. With [strict] (background scanning) images without a barcode are only
     * read further when they sit in a screenshot / KakaoTalk / download folder, to save battery.
     */
    @Synchronized
    fun process(c: Context, uri: Uri, strict: Boolean, pathHint: String = ""): Result {
        return try {
            val bmp = Images.load(c, uri, 1800) ?: return Result(Outcome.FAILED)
            if (strict && minOf(bmp.width, bmp.height) < 300) return Result(Outcome.NOT_COUPON)
            val img = InputImage.fromBitmap(bmp, 0)
            val code = try { Recognizer.barcode(img) } catch (e: Exception) { "" }
            if (strict && code.isEmpty() && !hintedPath.containsMatchIn(pathHint)) return Result(Outcome.NOT_COUPON)
            val text = try { Recognizer.text(img) } catch (e: Exception) { "" }
            val g = GiftParser.parse(text)
            val barcode = if (code.length >= 8) code else g.barcode
            val looksLikeCoupon = code.length >= 8 ||
                (g.expiry.isNotEmpty() && (g.brand.isNotEmpty() || GiftParser.COUPON_WORDS.containsMatchIn(text.replace(Regex("\\s+"), ""))))
            if (!looksLikeCoupon) return Result(Outcome.NOT_COUPON)
            if (barcode.isNotEmpty() && barcode in Store.knownBarcodes(c)) return Result(Outcome.DUPLICATE)

            val id = UUID.randomUUID().toString().replace("-", "").take(14)
            val small = Images.load(c, uri, 1300) ?: bmp
            val file = File(Store.pendingDir(c), "$id.jpg")
            Images.saveJpeg(small, file)
            val o = JSONObject()
                .put("id", id).put("brand", g.brand)
                .put("name", g.name.ifEmpty { if (g.brand.isNotEmpty()) "${g.brand} 기프티콘" else "기프티콘" })
                .put("barcode", barcode).put("expiry", g.expiry).put("type", g.type)
                .put("amount", if (g.type == "cash") g.amount else JSONObject.NULL)
                .put("memo", "").put("auto", true)
                .put("needsReview", barcode.isEmpty() || g.expiry.isEmpty() || g.name.isEmpty() || g.brand.isEmpty())
                .put("createdAt", System.currentTimeMillis())
                .put("imgFile", file.absolutePath)
            Store.addPending(c, o)
            Result(Outcome.ADDED, o)
        } catch (e: Throwable) {
            Result(Outcome.FAILED)
        }
    }

    /**
     * Looks at images added to the phone since the last scan (or since [sinceSec]).
     * Returns the coupons that were added.
     */
    @Synchronized
    fun scanNew(c: Context, sinceSec: Long? = null, notify: Boolean = true, limit: Int = 60): List<JSONObject> {
        if (!Perms.media(c)) return emptyList()
        val now = System.currentTimeMillis() / 1000
        val last = sinceSec ?: Prefs.lastScan(c).let { if (it == 0L) now - 600 else it }
        // look back a few minutes more: images saved slowly get their "date added" before they appear
        val from = if (sinceSec != null) sinceSec else last - 300
        val seen = Prefs.seenIds(c)
        val added = ArrayList<JSONObject>()
        val pathCol = if (Build.VERSION.SDK_INT >= 29) MediaStore.Images.Media.RELATIVE_PATH else MediaStore.Images.Media.DATA
        val projection = arrayOf(MediaStore.Images.Media._ID, MediaStore.Images.Media.DATE_ADDED, pathCol, MediaStore.Images.Media.DISPLAY_NAME)
        var newest = last
        c.contentResolver.query(
            MediaStore.Images.Media.EXTERNAL_CONTENT_URI, projection,
            "${MediaStore.Images.Media.DATE_ADDED} > ?", arrayOf(from.toString()),
            "${MediaStore.Images.Media.DATE_ADDED} ASC"
        )?.use { cur ->
            val iId = cur.getColumnIndexOrThrow(MediaStore.Images.Media._ID)
            val iDate = cur.getColumnIndexOrThrow(MediaStore.Images.Media.DATE_ADDED)
            val iPath = cur.getColumnIndex(pathCol)
            val iName = cur.getColumnIndex(MediaStore.Images.Media.DISPLAY_NAME)
            var count = 0
            while (cur.moveToNext() && count < limit) {
                val id = cur.getLong(iId)
                val key = id.toString()
                newest = maxOf(newest, cur.getLong(iDate))
                if (key in seen) continue
                seen.add(key); count++
                val hint = (if (iPath >= 0) cur.getString(iPath) ?: "" else "") + "/" + (if (iName >= 0) cur.getString(iName) ?: "" else "")
                val uri = ContentUris.withAppendedId(MediaStore.Images.Media.EXTERNAL_CONTENT_URI, id)
                val r = process(c, uri, strict = true, pathHint = hint)
                if (r.outcome == Outcome.ADDED && r.coupon != null) added.add(r.coupon)
            }
        }
        Prefs.setSeenIds(c, seen)
        if (sinceSec == null) Prefs.setLastScan(c, maxOf(newest, last))
        if (notify && added.isNotEmpty()) Notifier.imported(c, added)
        return added
    }
}
