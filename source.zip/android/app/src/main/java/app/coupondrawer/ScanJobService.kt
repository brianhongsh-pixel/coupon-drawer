package app.coupondrawer

import android.app.job.JobInfo
import android.app.job.JobParameters
import android.app.job.JobScheduler
import android.app.job.JobService
import android.content.ComponentName
import android.content.Context
import android.provider.MediaStore

/** Woken by Android whenever a new image lands in the phone's gallery (download, screenshot, camera). */
class ScanJobService : JobService() {
    override fun onStartJob(params: JobParameters): Boolean {
        Thread {
            try { Scanner.scanNew(applicationContext) } catch (_: Throwable) {}
            jobFinished(params, false)
            schedule(applicationContext) // content-trigger jobs fire once; arm again for the next image
        }.start()
        return true
    }

    override fun onStopJob(params: JobParameters): Boolean = false

    companion object {
        private const val JOB_ID = 4201

        fun schedule(c: Context) {
            val js = c.getSystemService(JobScheduler::class.java) ?: return
            val info = JobInfo.Builder(JOB_ID, ComponentName(c, ScanJobService::class.java))
                .addTriggerContentUri(JobInfo.TriggerContentUri(MediaStore.Images.Media.EXTERNAL_CONTENT_URI, JobInfo.TriggerContentUri.FLAG_NOTIFY_FOR_DESCENDANTS))
                .setTriggerContentUpdateDelay(3000)
                .setTriggerContentMaxDelay(20000)
                .build()
            try { js.schedule(info) } catch (_: Exception) {}
        }

        fun cancel(c: Context) {
            c.getSystemService(JobScheduler::class.java)?.cancel(JOB_ID)
        }
    }
}
