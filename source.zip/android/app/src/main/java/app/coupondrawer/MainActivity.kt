package app.coupondrawer

import android.annotation.SuppressLint
import android.content.Intent
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.webkit.ValueCallback
import android.webkit.WebChromeClient
import android.webkit.WebResourceRequest
import android.webkit.WebResourceResponse
import android.webkit.WebView
import androidx.activity.OnBackPressedCallback
import androidx.activity.result.contract.ActivityResultContracts
import androidx.appcompat.app.AppCompatActivity
import androidx.core.content.FileProvider
import androidx.webkit.WebViewAssetLoader
import androidx.webkit.WebViewClientCompat
import org.json.JSONObject
import java.io.File

class MainActivity : AppCompatActivity() {
    lateinit var web: WebView
    lateinit var bridge: Bridge
    private var fileCallback: ValueCallback<Array<Uri>>? = null
    private var cameraUri: Uri? = null

    private val pickFiles = registerForActivityResult(ActivityResultContracts.StartActivityForResult()) { res ->
        val cb = fileCallback; fileCallback = null
        var uris: Array<Uri>? = null
        if (res.resultCode == RESULT_OK) {
            val data = res.data
            val clip = data?.clipData
            uris = if (clip != null) Array(clip.itemCount) { clip.getItemAt(it).uri } else data?.data?.let { arrayOf(it) }
        }
        cb?.onReceiveValue(uris)
    }

    private val takePicture = registerForActivityResult(ActivityResultContracts.TakePicture()) { ok ->
        val cb = fileCallback; fileCallback = null
        val u = cameraUri
        cb?.onReceiveValue(if (ok && u != null) arrayOf(u) else null)
    }

    val askPermissions = registerForActivityResult(ActivityResultContracts.RequestMultiplePermissions()) {
        bridge.onPermissionsResult()
    }

    @SuppressLint("SetJavaScriptEnabled")
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        web = WebView(this)
        setContentView(web)

        val loader = WebViewAssetLoader.Builder()
            .addPathHandler("/", WebViewAssetLoader.AssetsPathHandler(this))
            .build()

        with(web.settings) {
            javaScriptEnabled = true
            domStorageEnabled = true
            databaseEnabled = true
            allowFileAccess = false
            allowContentAccess = true
            mediaPlaybackRequiresUserGesture = true
            textZoom = 100
        }

        web.webViewClient = object : WebViewClientCompat() {
            override fun shouldInterceptRequest(view: WebView, request: WebResourceRequest): WebResourceResponse? =
                loader.shouldInterceptRequest(request.url)

            override fun shouldOverrideUrlLoading(view: WebView, request: WebResourceRequest): Boolean {
                val u = request.url
                if (u.host == ASSET_HOST) return false
                try { startActivity(Intent(Intent.ACTION_VIEW, u)) } catch (_: Exception) {}
                return true
            }
        }

        web.webChromeClient = object : WebChromeClient() {
            override fun onShowFileChooser(view: WebView, cb: ValueCallback<Array<Uri>>, params: WebChromeClient.FileChooserParams): Boolean {
                fileCallback?.onReceiveValue(null)
                fileCallback = cb
                return try {
                    if (params.isCaptureEnabled) {
                        val f = File(cacheDir, "camera/shot_${System.currentTimeMillis()}.jpg").apply { parentFile?.mkdirs() }
                        val u = FileProvider.getUriForFile(this@MainActivity, "$packageName.files", f)
                        cameraUri = u
                        takePicture.launch(u)
                    } else {
                        val i = params.createIntent()
                        if (params.mode == WebChromeClient.FileChooserParams.MODE_OPEN_MULTIPLE) i.putExtra(Intent.EXTRA_ALLOW_MULTIPLE, true)
                        pickFiles.launch(i)
                    }
                    true
                } catch (e: Exception) {
                    fileCallback = null
                    cb.onReceiveValue(null)
                    true
                }
            }
        }

        bridge = Bridge(this)
        web.addJavascriptInterface(bridge, "CouponNative")
        if (BuildConfig.DEBUG) WebView.setWebContentsDebuggingEnabled(true)

        if (savedInstanceState != null) web.restoreState(savedInstanceState)
        else web.loadUrl("https://$ASSET_HOST/www/index.html")

        onBackPressedDispatcher.addCallback(this, object : OnBackPressedCallback(true) {
            override fun handleOnBackPressed() {
                web.evaluateJavascript("(window.__onBack && window.__onBack()) ? 'y' : 'n'") { r ->
                    if (r?.contains("y") != true) {
                        isEnabled = false
                        onBackPressedDispatcher.onBackPressed()
                        isEnabled = true
                    }
                }
            }
        })

        handleShare(intent)
    }

    override fun onSaveInstanceState(outState: Bundle) {
        super.onSaveInstanceState(outState)
        web.saveState(outState)
    }

    override fun onNewIntent(intent: Intent) {
        super.onNewIntent(intent)
        handleShare(intent)
    }

    override fun onResume() {
        super.onResume()
        js("window.__pullPending && window.__pullPending()")
    }

    fun js(code: String) = runOnUiThread { web.evaluateJavascript(code, null) }

    @Suppress("DEPRECATION")
    private fun handleShare(i: Intent?) {
        if (i == null) return
        val uris = ArrayList<Uri>()
        when (i.action) {
            Intent.ACTION_SEND -> {
                val u: Uri? = if (Build.VERSION.SDK_INT >= 33) i.getParcelableExtra(Intent.EXTRA_STREAM, Uri::class.java) else i.getParcelableExtra(Intent.EXTRA_STREAM)
                u?.let { uris.add(it) }
            }
            Intent.ACTION_SEND_MULTIPLE -> {
                val list: ArrayList<Uri>? = if (Build.VERSION.SDK_INT >= 33) i.getParcelableArrayListExtra(Intent.EXTRA_STREAM, Uri::class.java) else i.getParcelableArrayListExtra(Intent.EXTRA_STREAM)
                list?.let { uris.addAll(it) }
            }
            else -> return
        }
        setIntent(Intent(this, MainActivity::class.java))
        if (uris.isEmpty()) return
        js("window.__shareStart && window.__shareStart(${uris.size})")
        Thread {
            var dup = 0; var skip = 0; var fail = 0
            for (u in uris) {
                when (Scanner.process(applicationContext, u, strict = false).outcome) {
                    Scanner.Outcome.DUPLICATE -> dup++
                    Scanner.Outcome.NOT_COUPON -> skip++
                    Scanner.Outcome.FAILED -> fail++
                    else -> {}
                }
            }
            val summary = JSONObject().put("dup", dup).put("skip", skip).put("fail", fail)
            js("window.__shareDone ? window.__shareDone($summary) : 0")
        }.start()
    }

    companion object {
        const val ASSET_HOST = "appassets.androidplatform.net"
    }
}
