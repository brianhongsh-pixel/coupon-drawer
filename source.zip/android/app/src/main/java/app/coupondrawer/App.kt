package app.coupondrawer

import android.app.Application

class App : Application() {
    override fun onCreate() {
        super.onCreate()
        Notifier.createChannels(this)
        if (Prefs.autoDetect(this) && Perms.media(this)) ScanJobService.schedule(this)
        ExpiryWorker.schedule(this)
    }
}
