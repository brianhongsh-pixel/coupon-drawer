package app.coupondrawer

import android.app.Application
import java.time.LocalTime

class App : Application() {
    override fun onCreate() {
        super.onCreate()
        Notifier.createChannels(this)
        if (Prefs.autoDetect(this) && Perms.media(this)) ScanJobService.schedule(this)
        ExpiryWorker.schedule(this)
        // 예약 작업이 늦어질 수 있어서, 알림 시각이 지난 뒤 앱을 열면 한 번 더 확인해요.
        // 이미 보낸 알림은 다시 보내지 않아요.
        if (LocalTime.now().hour >= Prefs.alertHour(this)) {
            Thread { try { Notifier.checkExpiry(this) } catch (_: Throwable) {} }.start()
        }
    }
}
