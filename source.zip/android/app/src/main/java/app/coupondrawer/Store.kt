package app.coupondrawer

import android.content.Context
import android.util.Base64
import org.json.JSONArray
import org.json.JSONObject
import java.io.File

/** Hand-off between the background scanner and the web app (which owns the real database). */
object Store {
    private const val PENDING = "pending.json"
    private const val COUPONS = "coupons.json"

    private fun file(c: Context, name: String) = File(c.filesDir, name)
    fun pendingDir(c: Context) = File(c.filesDir, "pending").apply { mkdirs() }

    @Synchronized
    private fun readArray(c: Context, name: String): JSONArray =
        try { JSONArray(file(c, name).readText()) } catch (e: Exception) { JSONArray() }

    @Synchronized
    private fun writeText(c: Context, name: String, text: String) {
        val tmp = file(c, "$name.tmp")
        tmp.writeText(text)
        if (!tmp.renameTo(file(c, name))) { file(c, name).writeText(text); tmp.delete() }
    }

    @Synchronized
    fun addPending(c: Context, o: JSONObject) {
        val a = readArray(c, PENDING)
        a.put(o)
        writeText(c, PENDING, a.toString())
    }

    /** Returns pending coupons with their images as data URLs, and clears the queue. */
    @Synchronized
    fun takePending(c: Context): JSONArray {
        val a = readArray(c, PENDING)
        val out = JSONArray()
        for (i in 0 until a.length()) {
            val o = a.getJSONObject(i)
            val f = File(o.optString("imgFile"))
            if (f.exists()) {
                o.put("image", "data:image/jpeg;base64," + Base64.encodeToString(f.readBytes(), Base64.NO_WRAP))
                f.delete()
            }
            o.remove("imgFile")
            out.put(o)
        }
        writeText(c, PENDING, "[]")
        return out
    }

    fun pendingCount(c: Context) = readArray(c, PENDING).length()

    fun syncCoupons(c: Context, json: String) = writeText(c, COUPONS, json)

    /** Coupons the user has (synced from the web app) plus ones still waiting to be picked up. */
    fun allCoupons(c: Context): List<JSONObject> {
        val list = ArrayList<JSONObject>()
        for (name in listOf(COUPONS, PENDING)) {
            val a = readArray(c, name)
            for (i in 0 until a.length()) a.optJSONObject(i)?.let { list.add(it) }
        }
        return list
    }

    fun knownBarcodes(c: Context): Set<String> =
        allCoupons(c).mapNotNull { it.optString("barcode").takeIf { b -> b.isNotEmpty() } }.toSet()
}
