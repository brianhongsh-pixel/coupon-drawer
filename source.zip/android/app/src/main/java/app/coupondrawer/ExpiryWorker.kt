package app.coupondrawer

import android.content.Context
import androidx.work.ExistingPeriodicWorkPolicy
import androidx.work.PeriodicWorkRequestBuilder
import androidx.work.WorkManager
import androidx.work.Worker
import androidx.work.WorkerParameters
import java.time.Duration
import java.time.LocalDateTime
import java.util.concurrent.TimeUnit

/** Once a day at the alert hour: expiry reminders, plus a safety-net scan in case the gallery trigger was missed. */
class ExpiryWorker(c: Context, p: WorkerParameters) : Worker(c, p) {
    override fun doWork(): Result {
        val c = applicationContext
        if (Prefs.autoDetect(c) && Perms.media(c)) {
            ScanJobService.schedule(c)
            try { Scanner.scanNew(c) } catch (_: Throwable) {}
        }
        try { Notifier.checkExpiry(c) } catch (_: Throwable) {}
        return Result.success()
    }

    companion object {
        /** 하루 한 번, 알림 시각(기본 오전 9시)에 맞춰 예약해요. */
        fun schedule(c: Context) {
            val now = LocalDateTime.now()
            var next = now.toLocalDate().atTime(Prefs.alertHour(c), 0)
            if (!next.isAfter(now)) next = next.plusDays(1)
            val delay = Duration.between(now, next).coerceAtLeast(Duration.ofMinutes(1))
            WorkManager.getInstance(c).enqueueUniquePeriodicWork(
                "expiry-check", ExistingPeriodicWorkPolicy.UPDATE,
                PeriodicWorkRequestBuilder<ExpiryWorker>(1, TimeUnit.DAYS)
                    .setInitialDelay(delay)
                    .build()
            )
        }
    }
}
