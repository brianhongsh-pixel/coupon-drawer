package app.coupondrawer

import android.content.Context
import androidx.work.ExistingPeriodicWorkPolicy
import androidx.work.PeriodicWorkRequestBuilder
import androidx.work.WorkManager
import androidx.work.Worker
import androidx.work.WorkerParameters
import java.util.concurrent.TimeUnit

/** A few times a day: expiry reminders, plus a safety-net scan in case the gallery trigger was missed. */
class ExpiryWorker(c: Context, p: WorkerParameters) : Worker(c, p) {
    override fun doWork(): Result {
        val c = applicationContext
        if (Prefs.autoDetect(c) && Perms.media(c)) {
            ScanJobService.schedule(c)
            try { Scanner.scanNew(c) } catch (_: Throwable) {}
        }
        try { Notifier.checkExpiry(c) } catch (_: Throwable) {}
        return Result.success()
    }

    companion object {
        fun schedule(c: Context) {
            WorkManager.getInstance(c).enqueueUniquePeriodicWork(
                "expiry-check", ExistingPeriodicWorkPolicy.KEEP,
                PeriodicWorkRequestBuilder<ExpiryWorker>(6, TimeUnit.HOURS).build()
            )
        }
    }
}
