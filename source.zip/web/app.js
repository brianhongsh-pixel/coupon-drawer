/* 쿠폰서랍 — standalone PWA. All data stays on this device (IndexedDB). */
(() => {
"use strict";
const $ = s => document.querySelector(s);
const esc = s => String(s ?? "").replace(/[&<>"']/g, c => ({"&":"&amp;","<":"&lt;",">":"&gt;",'"':"&quot;","'":"&#39;"}[c]));
const won = n => (Number(n)||0).toLocaleString("ko-KR") + "원";
const uid = () => Date.now().toString(36) + Math.random().toString(36).slice(2, 8);
const ICON_X = '<svg viewBox="0 0 24 24" fill="none" stroke-width="2.4" stroke-linecap="round"><path d="M6 6l12 12M18 6 6 18"/></svg>';
const isoToday = () => { const d=new Date(); return `${d.getFullYear()}-${String(d.getMonth()+1).padStart(2,"0")}-${String(d.getDate()).padStart(2,"0")}`; };

/* ---------- Android app bridge (window.CouponNative exists only inside the installed Android app) ---------- */
const NATIVE = window.CouponNative || null;
const nCalls = {}; let nSeq = 0;
window.__nativeDone = (id, json) => { const f = nCalls[id]; delete nCalls[id]; if(f){ try{ f(JSON.parse(json)); }catch(e){ f({}); } } };
function nativeCall(method, ...args){ return new Promise(res => { const id = "c"+(++nSeq); nCalls[id] = res; try{ NATIVE[method](id, ...args); }catch(e){ delete nCalls[id]; res({error:String(e)}); } }); }
const nStatus = () => { try{ return JSON.parse(NATIVE.status()); }catch(e){ return {}; } };
if(NATIVE) document.documentElement.classList.add("native");

/* ---------- dates ---------- */
function todayKey(){ const d=new Date(); return new Date(d.getFullYear(),d.getMonth(),d.getDate()).getTime(); }
function daysLeft(exp){
  if(!exp) return null;
  const [y,m,d] = exp.split("-").map(Number); if(!y||!m||!d) return null;
  return Math.round((new Date(y,m-1,d).getTime() - todayKey())/86400000);
}
function fmtDate(exp){ if(!exp) return "기한 없음"; const [y,m,d]=exp.split("-"); return `${y}.${m}.${d}`; }
function statusOf(g){ if(g.used) return "used"; const n=daysLeft(g.expiry); if(n!==null && n<0) return "expired"; return "avail"; }
function urgency(g){ const n=daysLeft(g.expiry); if(n===null) return ""; if(n<=3) return "urgent"; if(n<=14) return "soon"; return ""; }
function ddayText(n){ if(n===null) return "∞"; if(n===0) return "D-DAY"; return n>0 ? "D-"+n : "D+"+(-n); }
function balanceOf(g){ if(g.type!=="cash") return null; const used=(g.history||[]).reduce((a,h)=>a+(Number(h.amount)||0),0); return Math.max(0,(Number(g.amount)||0)-used); }

/* ---------- storage (IndexedDB, shared with the service worker for alerts) ---------- */
const DB = {
  _db:null,
  open(){ return this._db || (this._db = new Promise((res,rej)=>{
    const r = indexedDB.open("coupon-drawer",1);
    r.onupgradeneeded = () => { r.result.createObjectStore("items",{keyPath:"id"}); r.result.createObjectStore("imgs"); r.result.createObjectStore("meta"); };
    r.onsuccess = () => res(r.result); r.onerror = () => rej(r.error);
  })); },
  async tx(store, mode, fn){ const db=await this.open(); return new Promise((res,rej)=>{ const t=db.transaction(store,mode); const out=fn(t.objectStore(store)); t.oncomplete=()=>res(out&&out.result); t.onerror=()=>rej(t.error); t.onabort=()=>rej(t.error); }); },
  list(){ return this.tx("items","readonly",s=>s.getAll()).then(r=>r||[]); },
  put(g){ return this.tx("items","readwrite",s=>s.put(g)); },
  async del(id){ await this.tx("items","readwrite",s=>s.delete(id)); await this.tx("imgs","readwrite",s=>s.delete(id)); },
  getImg(id){ return this.tx("imgs","readonly",s=>s.get(id)); },
  putImg(id,data){ return this.tx("imgs","readwrite",s=>s.put(data,id)); },
  getMeta(k){ return this.tx("meta","readonly",s=>s.get(k)); },
  setMeta(k,v){ return this.tx("meta","readwrite",s=>s.put(v,k)); }
};

let items = [], loaded = false;
const imgCache = new Map();
const ui = { tab:"avail", brand:"", q:"", review:false };
async function reload(){
  try{ items = await DB.list(); }catch(e){ toast("저장소를 열 수 없어요. 시크릿 모드가 아닌지 확인해 주세요."); }
  loaded = true; render();
  if(NATIVE){ try{ NATIVE.syncCoupons(JSON.stringify(items.map(g=>({id:g.id, brand:g.brand, name:g.name, barcode:g.barcode, expiry:g.expiry, used: statusOf(g)!=="avail"})))); }catch(e){} }
}

/* ---------- examples (only while empty) ---------- */
function plusDays(n){ const d=new Date(); d.setDate(d.getDate()+n); return `${d.getFullYear()}-${String(d.getMonth()+1).padStart(2,"0")}-${String(d.getDate()).padStart(2,"0")}`; }
const EXAMPLES = [
  {id:"ex1", brand:"스타벅스", name:"카페 아메리카노 T 2잔", expiry:plusDays(2), type:"item"},
  {id:"ex2", brand:"CU", name:"모바일 금액권 1만원", expiry:plusDays(9), type:"cash", amount:10000, history:[{date:plusDays(-3),amount:4200}]},
  {id:"ex3", brand:"배스킨라빈스", name:"파인트 아이스크림", expiry:plusDays(41), type:"item"}
];

/* ---------- render ---------- */
function render(){
  const by = {avail:[],used:[],expired:[]};
  items.forEach(g => by[statusOf(g)].push(g));
  const soon = by.avail.filter(g => { const n=daysLeft(g.expiry); return n!==null && n<=7; }).sort((a,b)=>daysLeft(a.expiry)-daysLeft(b.expiry));
  const cash = by.avail.reduce((a,g)=>a+(balanceOf(g)||0),0);
  $("#sAvail").textContent = loaded ? by.avail.length : "–";
  $("#sSoon").textContent = loaded ? soon.length : "–";
  $("#sCash").textContent = loaded ? cash.toLocaleString("ko-KR") : "–";
  $("#cAvail").textContent = by.avail.length || ""; $("#cUsed").textContent = by.used.length || ""; $("#cExp").textContent = by.expired.length || "";
  const today = by.avail.filter(g=>daysLeft(g.expiry)===0);
  const al = $("#alert");
  if(today.length){ al.hidden=false; al.textContent = `오늘 만료: ${today.map(g=>g.brand||g.name).join(", ")}. 오늘 꼭 사용하세요.`; }
  else if(soon.length){ al.hidden=false; al.textContent = `${soon.length}개가 7일 안에 만료돼요. 가장 빠른 것: ${soon[0].brand||soon[0].name||"쿠폰"} (${ddayText(daysLeft(soon[0].expiry))})`; }
  else al.hidden=true;

  document.querySelectorAll(".tabs button").forEach(b => b.setAttribute("aria-selected", b.dataset.tab===ui.tab));
  let rows = by[ui.tab];
  const brands = [...new Set(rows.map(g=>g.brand).filter(Boolean))].sort((a,b)=>a.localeCompare(b,"ko"));
  if(ui.brand && !brands.includes(ui.brand)) ui.brand="";
  const nRev = rows.filter(g=>g.needsReview).length;
  if(!nRev) ui.review = false;
  const revChip = nRev ? `<button class="chip rev" data-act="review" aria-pressed="${ui.review}">확인 필요 ${nRev}</button>` : "";
  $("#chips").innerHTML = revChip + (brands.length>1 ? ['<button class="chip" data-brand="" aria-pressed="'+(!ui.brand)+'">전체</button>'].concat(brands.map(b=>`<button class="chip" data-brand="${esc(b)}" aria-pressed="${ui.brand===b}">${esc(b)}</button>`)).join("") : "");
  if(ui.review) rows = rows.filter(g=>g.needsReview);
  if(ui.brand) rows = rows.filter(g=>g.brand===ui.brand);
  if(ui.q){ const q=ui.q.toLowerCase(); rows = rows.filter(g => (g.brand+" "+g.name+" "+(g.memo||"")).toLowerCase().includes(q)); }
  rows.sort(ui.tab==="avail" ? (a,b)=>(daysLeft(a.expiry)??1e9)-(daysLeft(b.expiry)??1e9) : (a,b)=>(b.updatedAt||0)-(a.updatedAt||0));

  const list = $("#list");
  if(!loaded){ list.innerHTML = '<div class="empty"><p>쿠폰을 불러오는 중…</p></div>'; return; }
  if(!items.length){
    list.innerHTML = `<div class="empty"><h2>서랍이 비어 있어요</h2><p>받은 기프티콘 이미지를 고르거나 사진을 찍기만 하면, 자동으로 읽어서 등록하고 유효기간 순으로 정리해요. 여러 장을 한꺼번에 골라도 쿠폰만 골라서 등록해요.</p><div class="row" style="margin-top:14px"><button class="btn primary" data-act="add">이미지 한꺼번에 불러오기</button><button class="btn" data-act="camera">사진 찍기</button></div></div>
      <div class="sec-label">이렇게 보여요 · 예시</div>` + EXAMPLES.map(g=>ticket(g,true)).join("");
    return;
  }
  if(!rows.length){
    const msg = ui.q||ui.brand ? "조건에 맞는 쿠폰이 없어요." : ui.tab==="avail" ? "사용 가능한 쿠폰이 없어요." : ui.tab==="used" ? "아직 사용한 쿠폰이 없어요." : "만료된 쿠폰이 없어요.";
    list.innerHTML = `<div class="empty"><p>${msg}</p></div>`; return;
  }
  list.innerHTML = rows.map(g=>ticket(g,false)).join("");
  rows.forEach(g => loadThumb(g.id));
}

function ticket(g, example){
  const st = statusOf(g), n = daysLeft(g.expiry), bal = balanceOf(g);
  const cls = ["ticket", st==="used"?"done":st==="expired"?"expired":urgency(g), example?"example":""].join(" ");
  const stub = st==="used" ? `<span class="dday">사용</span><small>완료</small>` : st==="expired" ? `<span class="dday">만료</span><small>${esc(fmtDate(g.expiry).slice(2))}</small>` : `<span class="dday">${ddayText(n)}</span><small>${n===0?"오늘까지":n===null?"기한없음":"남음"}</small>`;
  const img = imgCache.get(g.id);
  return `<button class="${cls}" ${example?'tabindex="-1" aria-hidden="true"':`data-open="${esc(g.id)}"`}>
    ${example?'<span class="tag">예시</span>':g.needsReview?'<span class="tag rev">확인</span>':""}
    <span class="thumb" id="th_${esc(g.id)}">${img?`<img src="${img}" alt="">`:`<span class="ph">${esc((g.brand||"?").slice(0,1))}</span>`}</span>
    <span class="body"><span class="b1">${esc(g.brand||"교환처 미입력")}</span><span class="b2">${esc(g.name||"상품명 미입력")}</span>
    <span class="b3">${g.expiry?esc(fmtDate(g.expiry))+"까지":"유효기간 확인 필요"}${bal!==null?` · 잔액 <span class="bal">${won(bal)}</span>`:""}</span></span>
    <span class="stub">${stub}</span></button>`;
}
async function loadThumb(id){
  if(imgCache.has(id)) return;
  imgCache.set(id, null);
  try{ const d = await DB.getImg(id); if(d){ imgCache.set(id,d); const el=document.getElementById("th_"+id); if(el) el.innerHTML=`<img src="${d}" alt="">`; } }catch(e){ imgCache.delete(id); }
}

/* ---------- sheets & toast ---------- */
function openSheet(html, onMount){
  const layer = $("#layer");
  layer.innerHTML = `<div class="scrim" id="scrim"><div class="sheet" role="dialog" aria-modal="true"><div class="grab"></div>${html}</div></div>`;
  $("#scrim").addEventListener("click", e => { if(e.target.id==="scrim") closeSheet(); });
  document.body.style.overflow="hidden";
  onMount && onMount(layer.querySelector(".sheet"));
}
let afterClose = null;
function closeSheet(){ $("#layer").innerHTML=""; document.body.style.overflow=""; render(); const f = afterClose; afterClose = null; if(f) setTimeout(f, 250); }
function head(t){ return `<div class="sheet-head"><h2>${t}</h2><button class="close" data-act="close" aria-label="닫기">${ICON_X}</button></div>`; }
let toastT;
function toast(msg){ let t=$("#toast"); if(!t){ t=document.createElement("div"); t.id="toast"; t.className="toast"; t.setAttribute("role","status"); document.body.appendChild(t);} t.textContent=msg; t.hidden=false; clearTimeout(toastT); toastT=setTimeout(()=>t.hidden=true,2600); }

/* ---------- on-device recognition ---------- */
let zxingP = null, tessP = null, tessWorker = null;
function loadScript(src){ return new Promise((res,rej)=>{ const s=document.createElement("script"); s.src=src; s.onload=res; s.onerror=()=>rej(new Error("load "+src)); document.head.appendChild(s); }); }
function absUrl(p){ return new URL(p, location.href).href; }

/* image helpers: camera photos are tilted, dark and have background around the coupon */
async function toCanvas(src, maxW){
  const bmp = src instanceof HTMLCanvasElement ? src : await createImageBitmap(src);
  const s = Math.min(1, (maxW||2000) / Math.max(bmp.width, bmp.height));
  const c = document.createElement("canvas"); c.width = Math.round(bmp.width*s); c.height = Math.round(bmp.height*s);
  const x = c.getContext("2d", {willReadFrequently:true}); x.fillStyle="#fff"; x.fillRect(0,0,c.width,c.height); x.drawImage(bmp,0,0,c.width,c.height);
  return c;
}
function otsu(hist, total){
  let sum=0; for(let i=0;i<256;i++) sum+=i*hist[i];
  let sumB=0,wB=0,best=0,th=128;
  for(let i=0;i<256;i++){ wB+=hist[i]; if(!wB) continue; const wF=total-wB; if(!wF) break; sumB+=i*hist[i]; const mB=sumB/wB, mF=(sum-sumB)/wF, v=wB*wF*(mB-mF)*(mB-mF); if(v>best){best=v;th=i;} }
  return th;
}
// grayscale + crop to the bright document/screen area + contrast stretch
function cleanUp(c){
  const x = c.getContext("2d", {willReadFrequently:true});
  const im = x.getImageData(0,0,c.width,c.height), d = im.data, n = c.width*c.height;
  const g = new Uint8ClampedArray(n), hist = new Array(256).fill(0);
  for(let i=0,j=0;i<n;i++,j+=4){ const v = (d[j]*299 + d[j+1]*587 + d[j+2]*114)/1000|0; g[i]=v; hist[v]++; }
  const th = otsu(hist, n);
  // bounding box of rows/cols that are mostly bright (the coupon itself)
  const rowOk = r => { let k=0; for(let i=0;i<c.width;i++) if(g[r*c.width+i]>th) k++; return k > c.width*0.35; };
  const colOk = q => { let k=0; for(let r=0;r<c.height;r++) if(g[r*c.width+q]>th) k++; return k > c.height*0.35; };
  let top=0,bot=c.height-1,lef=0,rig=c.width-1;
  while(top<bot && !rowOk(top)) top++; while(bot>top && !rowOk(bot)) bot--;
  while(lef<rig && !colOk(lef)) lef++; while(rig>lef && !colOk(rig)) rig--;
  const cw = rig-lef+1, ch = bot-top+1;
  const crop = (cw*ch > n*0.12 && cw*ch < n*0.97) ? {x:lef,y:top,w:cw,h:ch} : {x:0,y:0,w:c.width,h:c.height};
  // contrast stretch inside the crop
  let lo=255, hi=0; const h2=new Array(256).fill(0); let cnt=0;
  for(let r=crop.y;r<crop.y+crop.h;r++) for(let q=crop.x;q<crop.x+crop.w;q++){ h2[g[r*c.width+q]]++; cnt++; }
  let acc=0; for(let i=0;i<256;i++){ acc+=h2[i]; if(acc>cnt*0.02){ lo=i; break; } }
  acc=0; for(let i=255;i>=0;i--){ acc+=h2[i]; if(acc>cnt*0.02){ hi=i; break; } }
  const span = Math.max(1, hi-lo);
  const o = document.createElement("canvas"); o.width = crop.w; o.height = crop.h;
  const ox = o.getContext("2d"); const oi = ox.createImageData(crop.w, crop.h); const od = oi.data;
  for(let r=0;r<crop.h;r++) for(let q=0;q<crop.w;q++){ const v = Math.max(0,Math.min(255,((g[(r+crop.y)*c.width+q+crop.x]-lo)*255/span)|0)); const k=(r*crop.w+q)*4; od[k]=od[k+1]=od[k+2]=v; od[k+3]=255; }
  ox.putImageData(oi,0,0);
  return o;
}
function rotated(c, deg){
  const r = deg*Math.PI/180, sin=Math.abs(Math.sin(r)), cos=Math.abs(Math.cos(r));
  const o = document.createElement("canvas"); o.width = Math.round(c.width*cos + c.height*sin); o.height = Math.round(c.width*sin + c.height*cos);
  const x = o.getContext("2d"); x.fillStyle="#fff"; x.fillRect(0,0,o.width,o.height);
  x.translate(o.width/2, o.height/2); x.rotate(r); x.drawImage(c, -c.width/2, -c.height/2);
  return o;
}

async function zxingRead(canvas){
  zxingP = zxingP || loadScript("vendor/zxing.min.js");
  await zxingP;
  const Z = window.ZXing;
  const hints = new Map();
  hints.set(Z.DecodeHintType.TRY_HARDER, true);
  hints.set(Z.DecodeHintType.POSSIBLE_FORMATS, [Z.BarcodeFormat.CODE_128, Z.BarcodeFormat.EAN_13, Z.BarcodeFormat.ITF, Z.BarcodeFormat.CODE_39, Z.BarcodeFormat.QR_CODE]);
  const reader = new Z.MultiFormatReader(); reader.setHints(hints);
  try{
    const lum = new Z.HTMLCanvasElementLuminanceSource(canvas);
    for(const bin of [new Z.HybridBinarizer(lum), new Z.GlobalHistogramBinarizer(lum)]){
      try{ return reader.decode(new Z.BinaryBitmap(bin), hints).getText(); }catch(e){}
    }
  }catch(e){}
  return "";
}
async function readBarcode(blob, cleaned){
  if("BarcodeDetector" in window){
    try{
      const bd = new BarcodeDetector();
      const r = await bd.detect(await createImageBitmap(blob));
      const hit = r.find(x => x.format!=="qr_code" && /\d{8,}/.test(x.rawValue)) || r[0];
      if(hit && hit.rawValue) return hit.rawValue;
    }catch(e){}
  }
  const base = await toCanvas(blob, 1600);
  const tries = [base, cleaned, ...(cleaned ? [-6,6,-12,12,90].map(d=>rotated(cleaned,d)) : [])].filter(Boolean);
  for(const c of tries){ const t = await zxingRead(c); if(t) return t; }
  return "";
}

async function getTess(onProgress){
  if(tessWorker) return tessWorker;
  tessP = tessP || loadScript("vendor/tesseract/tesseract.min.js");
  await tessP;
  tessWorker = await window.Tesseract.createWorker(["kor","eng"], 1, {
    workerPath: absUrl("vendor/tesseract/worker.min.js"),
    corePath: absUrl("vendor/tesseract/"),
    langPath: absUrl("vendor/lang"),
    gzip: true, workerBlobURL: false, cacheMethod: "none",
    logger: m => tessLog && tessLog(m)
  });
  return tessWorker;
}
let tessLog = null;
function scoreText(t){ const r = parseGift(t); return (r.expiry?3:0)+(r.brand?2:0)+(r.barcode?2:0)+(r.name?1:0)+Math.min(2,(t.match(/[가-힣]/g)||[]).length/40); }
function scaleTo(c, w){ if(c.width>=w*0.9 && c.width<=w*1.1) return c; const s=w/c.width; const o=document.createElement("canvas"); o.width=Math.round(c.width*s); o.height=Math.round(c.height*s); const x=o.getContext("2d"); x.imageSmoothingQuality="high"; x.drawImage(c,0,0,o.width,o.height); return o; }
// OCR the plain image; if it reads poorly (typical for camera photos) also try the cleaned/rotated versions and keep the best
async function ocrText(blob, onProgress, cleaned){
  const w = await getTess();
  tessLog = onProgress;
  const raw = await toCanvas(blob, 2400); const plain = scaleTo(raw, Math.min(1600, Math.max(1000, raw.width)));
  let best = (await w.recognize(plain)).data.text || "", bestScore = scoreText(best);
  if(bestScore < 5 && cleaned){
    for(const c of [cleaned, rotated(cleaned,-5), rotated(cleaned,5)]){
      const t = (await w.recognize(scaleTo(c, 1300))).data.text || ""; const sc = scoreText(t);
      if(sc > bestScore){ best = t; bestScore = sc; }
      if(bestScore >= 6) break;
    }
  }
  tessLog = null;
  return best;
}

const BRANDS = ["스타벅스","투썸플레이스","투썸","이디야","메가MGC커피","메가커피","컴포즈커피","빽다방","할리스","폴바셋","커피빈","탐앤탐스","파스쿠찌","엔제리너스","공차","설빙","배스킨라빈스","던킨","크리스피크림","파리바게뜨","뚜레쥬르","성심당","맥도날드","버거킹","롯데리아","맘스터치","KFC","쉐이크쉑","서브웨이","BHC","BBQ","교촌치킨","교촌","굽네치킨","굽네","노랑통닭","처갓집","푸라닭","60계","네네치킨","도미노피자","피자헛","파파존스","미스터피자","피자스쿨","CU","GS25","세븐일레븐","이마트24","미니스톱","이마트","홈플러스","롯데마트","GS더프레시","올리브영","다이소","신세계","롯데백화점","현대백화점","갤러리아","배달의민족","배민","요기요","쿠팡이츠","컬리","CGV","메가박스","롯데시네마","교보문고","영풍문고","예스24","아웃백","빕스","VIPS","애슐리","본죽","죽이야기","한솥","김밥천국","exbuy","구글플레이","Google Play","문화상품권","컬쳐랜드","해피머니","북앤라이프","스마일캐시","네이버페이","카카오페이"];
const STOP = /(유효기간|교환처|주문번호|쿠폰번호|사용기한|카카오톡|선물하기|kakao|gift|바코드|사용처|사용방법|유의사항|발행일|선물|gifticon|일시|상품권번호|인증번호|PIN)/i;
// common OCR confusions for brand names
const FIXES = [[/[6G][S5$]\s?25/g,"GS25"],[/C\s?U(?![a-z])/g,"CU"],[/이마트\s?2[4A]/g,"이마트24"],[/세븐\s?일레븐/g,"세븐일레븐"]];

function parseGift(raw){
  let text = raw.replace(/\r/g,"");
  FIXES.forEach(([re,v]) => { text = text.replace(re, v); });
  const lines = text.split("\n").map(l=>l.trim()).filter(Boolean);
  const squash = s => s.replace(/\s+/g,"");
  const flat = squash(text);
  const out = { brand:"", name:"", barcode:"", expiry:"", type:"item", amount:"" };

  // expiry: prefer the date on a 유효기간/까지 line, else the latest date
  const dateRe = /(20\d{2})\s*[.\-\/년]\s*(\d{1,2})\s*[.\-\/월]\s*(\d{1,2})/g;
  const cands = [];
  lines.forEach(l => { let m; dateRe.lastIndex=0; while((m=dateRe.exec(l))){ const y=+m[1], mo=+m[2], d=+m[3]; if(mo>=1&&mo<=12&&d>=1&&d<=31){ cands.push({iso:`${y}-${String(mo).padStart(2,"0")}-${String(d).padStart(2,"0")}`, pri:/(유효|기한|까지|만료|~)/.test(l)?1:0}); } } });
  if(cands.length){ cands.sort((a,b)=> b.pri-a.pri || b.iso.localeCompare(a.iso)); out.expiry = cands[0].iso; }

  // brand: known brand names first, then the "교환처" label
  const low = flat.toLowerCase();
  const hit = BRANDS.find(b => low.includes(b.toLowerCase().replace(/\s+/g,"")));
  if(hit) out.brand = hit==="투썸"?"투썸플레이스":hit==="배민"?"배달의민족":hit;
  if(!out.brand){
    const labelBrand = lines.find(l=>/교환처|사용처/.test(squash(l)));
    if(labelBrand){ const v = labelBrand.replace(/.*(교\s*환\s*처|사\s*용\s*처)\s*[:：]?\s*/,"").trim(); if(v && v.length<=20 && /[가-힣A-Za-z]/.test(v)) out.brand = v; }
  }
  // product name: after "상품명" label, else first meaningful Hangul line
  const labelName = lines.find(l=>/상품명/.test(squash(l)));
  if(labelName){ out.name = labelName.replace(/.*상\s*품\s*명\s*[:：]?\s*/,"").replace(/(\d)\s*(7%|7H|7\]|7\})(?=\s|$)/g,"$1잔").trim(); }
  if(!out.name){
    const cand = lines.find(l => { const h=(l.match(/[가-힣]/g)||[]).length; return h>=3 && !STOP.test(squash(l)) && !/^\d/.test(l) && squash(l)!==squash(out.brand) && !/20\d{2}\s*[.\-\/년]/.test(l); });
    if(cand) out.name = cand.replace(/(\d)\s*(7%|7H|7\]|7\})(?=\s|$)/g,"$1잔").replace(/[|_~]+/g," ").replace(/\s{2,}/g," ").trim();
  }

  // coupon number fallback from text: longest run of 10~20 digits (spaces/hyphens allowed)
  const nums = (text.match(/\d[\d \-]{9,28}\d/g)||[]).map(s=>s.replace(/[ \-]/g,"")).filter(s=>s.length>=10 && s.length<=20 && !/^20\d{6}$/.test(s));
  if(nums.length) out.barcode = nums.sort((a,b)=>b.length-a.length)[0];

  // cash voucher
  if(/(금액권|상품권|충전|잔액|모바일교환권\d|원권|만원권)/.test(flat)){
    const m = flat.match(/(\d{1,3}(?:,\d{3})+|\d{4,7})원/) || flat.match(/(\d{1,2})만원/);
    if(m){ out.type="cash"; out.amount = m[0].includes("만원") && !m[0].includes(",") && m[1].length<=2 ? String(+m[1]*10000) : m[1].replace(/,/g,""); }
  }
  return out;
}

/* ---------- automatic import: pick / shoot / share → recognized → registered ---------- */
let importing = false; const pending = [];
const sha = async str => { try{ const b = await crypto.subtle.digest("SHA-256", new TextEncoder().encode(str)); return [...new Uint8Array(b)].slice(0,12).map(x=>x.toString(16).padStart(2,"0")).join(""); }catch(e){ return ""; } };
function onFiles(files){
  const list = [...files].filter(f=>f && (f.type||"").startsWith("image/"));
  if(!list.length) return;
  pending.push(...list);
  if(!importing) runImport();
}
function bar(msg, pct){
  const b = $("#importBar"); if(!b) return;
  if(msg===null){ b.hidden = true; return; }
  b.hidden = false; $("#importMsg").textContent = msg; $("#importFill").style.width = Math.round((pct||0)*100)+"%";
}
async function runImport(){
  importing = true;
  const result = { added:[], review:[], dup:[], skip:0, fail:0 };
  let done = 0;
  while(pending.length){
    const total = done + pending.length;
    const f = pending.shift();
    bar(`자동 등록 중 ${done+1}/${total}${tessWorker||NATIVE?"":" · 처음 한 번 인식 데이터를 받는 중"}`, done/total);
    try{
      const r = await autoRecognize(f, p => bar(`자동 등록 중 ${done+1}/${total} · 글자 읽는 중`, (done + p*0.9)/total));
      if(!r){ result.skip++; }
      else if(r.dup){ result.dup.push(r.item); }
      else { (r.item.needsReview ? result.review : result.added).push(r.item); }
    }catch(e){ result.fail++; }
    done++;
    await reload();
  }
  bar(null); importing = false;
  scheduleAlerts();
  showImportResult(result);
}

async function autoRecognize(file, onPct){
  const img = await compress(file);
  const hash = await sha(img);
  if(hash && items.some(x=>x.imgHash===hash)) return { dup:true, item: items.find(x=>x.imgHash===hash) };

  let code = "", text = "";
  if(NATIVE){
    const r = await nativeCall("recognize", img.split(",")[1]);
    code = (r.barcode||"").replace(/[\s-]/g,""); text = r.text || "";
  } else {
    let cleaned = null;
    try{ cleaned = cleanUp(await toCanvas(file, 1800)); }catch(e){}
    try{ code = (await readBarcode(file, cleaned) || "").replace(/[\s-]/g,""); }catch(e){}
    try{ text = await ocrText(file, m => { if(m.status==="recognizing text") onPct(m.progress||0); }, cleaned); }catch(e){}
  }
  const r = parseGift(text);
  const barcode = (code && code.length>=8) ? code : r.barcode;
  const looksLikeCoupon = (code && code.length>=8) || (r.expiry && (r.brand || /(유효기간|교환처|쿠폰|상품권|기프티콘|선물|사용기한|교환권)/.test(text.replace(/\s+/g,""))));
  if(!looksLikeCoupon) return null;

  const dupItem = barcode && items.find(x=>x.barcode===barcode);
  if(dupItem) return { dup:true, item:dupItem };

  const g = {
    id: uid(), brand: r.brand, name: r.name || (r.brand ? r.brand+" 기프티콘" : "기프티콘"),
    barcode: barcode || "", expiry: r.expiry || "", type: r.type, amount: r.type==="cash" ? Number(r.amount)||0 : null,
    memo:"", used:false, history:[], imgHash: hash, auto:true,
    needsReview: !barcode || !r.expiry || !r.name || !r.brand,
    createdAt: Date.now(), updatedAt: Date.now()
  };
  await DB.putImg(g.id, img); imgCache.set(g.id, img);
  await DB.put(g);
  return { item:g };
}

/* coupons the Android app found in the gallery (or got through the share sheet) while this screen was closed */
let pulling = false;
window.__pullPending = async (summary) => {
  if(!NATIVE || pulling) return; pulling = true;
  try{
    let arr = [];
    try{ arr = JSON.parse(NATIVE.takePending() || "[]"); }catch(e){}
    const r = { added:[], review:[], dup:[], dupN:(summary&&summary.dup)||0, skip:(summary&&summary.skip)||0, fail:(summary&&summary.fail)||0, title: summary ? "" : "새 쿠폰 " };
    for(const p of arr){
      const { image, ...g } = p;
      if(g.barcode && items.some(x=>x.barcode===g.barcode)){ r.dupN++; continue; }
      g.history = []; g.used = false; g.updatedAt = Date.now();
      if(image){ g.imgHash = await sha(image); await DB.putImg(g.id, image); imgCache.set(g.id, image); }
      await DB.put(g); items.push(g);
      (g.needsReview ? r.review : r.added).push(g);
    }
    if(arr.length || summary){ await reload(); ui.tab = "avail"; showImportResult(r); }
  } finally { pulling = false; bar(null); }
};
window.__shareStart = n => bar(`공유받은 이미지 ${n}장을 읽는 중…`, 0.4);
window.__shareDone = s => window.__pullPending(s || {});
window.__onBack = () => { const f = $("#full"); if(f){ f.click(); return true; } if($("#scrim")){ closeSheet(); return true; } return false; };

function showImportResult(r){
  const n = r.added.length + r.review.length;
  const row = (g, tag) => `<button class="res" data-open="${esc(g.id)}"><span class="res-t"><b>${esc(g.brand||"교환처 확인 필요")}</b> ${esc(g.name)}</span><span class="res-s">${tag}</span></button>`;
  if(n && !r.review.length && !r.dup.length && !r.dupN && !r.skip && !r.fail){ toast(`${n}개를 자동으로 등록했어요`); ui.tab="avail"; render(); return; }
  openSheet(`${head(n ? `${r.title||""}${n}개를 자동 등록했어요` : "새로 등록된 쿠폰이 없어요")}
    ${r.added.map(g=>row(g, `<span class="pill">${g.expiry?ddayText(daysLeft(g.expiry)):"등록"}</span>`)).join("")}
    ${r.review.length?`<div class="sec">확인이 필요해요 · 일부 칸을 못 읽었어요</div>${r.review.map(g=>row(g,'<span class="pill soon">확인</span>')).join("")}`:""}
    ${r.dup.length?`<div class="sec">이미 서랍에 있어서 건너뛰었어요</div>${r.dup.map(g=>row(g,'<span class="pill off">중복</span>')).join("")}`:""}
    ${r.dupN?`<p class="note">이미 서랍에 있는 쿠폰 ${r.dupN}장은 건너뛰었어요.</p>`:""}
    ${r.skip?`<p class="note">쿠폰이 아닌 사진 ${r.skip}장은 건너뛰었어요.</p>`:""}
    ${r.fail?`<p class="note">${r.fail}장은 열 수 없었어요.</p>`:""}
    <div class="row" style="margin-top:12px"><button class="btn primary" data-act="close">확인</button></div>`);
}
function compress(file){
  return new Promise((res,rej)=>{
    const img = new Image(); const url = URL.createObjectURL(file);
    img.onload = () => {
      let max = 1300, q = 0.85, out;
      for(let i=0;i<5;i++){
        const s = Math.min(1, max/Math.max(img.width,img.height));
        const c = document.createElement("canvas"); c.width=Math.round(img.width*s); c.height=Math.round(img.height*s);
        const x = c.getContext("2d"); x.fillStyle="#fff"; x.fillRect(0,0,c.width,c.height); x.drawImage(img,0,0,c.width,c.height);
        out = c.toDataURL("image/jpeg", q);
        if(out.length < 400000) break;
        max = Math.round(max*0.85); q = Math.max(0.6, q-0.05);
      }
      URL.revokeObjectURL(url); res(out);
    };
    img.onerror = () => { URL.revokeObjectURL(url); rej(new Error("img")); };
    img.src = url;
  });
}
function setType(t){ document.querySelectorAll("#fType button").forEach(b=>b.setAttribute("aria-pressed", b.dataset.type===t)); const a=$("#amountWrap"); if(a) a.hidden = t!=="cash"; }

function editForm(g, isNew){
  const img = g._img || imgCache.get(g.id);
  openSheet(`${head(isNew?"기프티콘 추가":"정보 수정")}
    ${img?`<div class="preview"><img src="${img}" alt="기프티콘 이미지"></div>`:""}
        <form id="form" autocomplete="off">
      <input type="hidden" id="fId" value="${esc(g.id)}">
      <div class="field"><label for="fBrand">교환처</label><input id="fBrand" value="${esc(g.brand)}" placeholder="예: 스타벅스"></div>
      <div class="field"><label for="fName">상품명</label><input id="fName" value="${esc(g.name)}" placeholder="예: 카페 아메리카노 T"></div>
      <div class="field"><label for="fBarcode">쿠폰번호(바코드)</label><input id="fBarcode" value="${esc(g.barcode)}" inputmode="numeric" placeholder="숫자만 입력"></div>
      <div class="field"><label for="fExpiry">유효기간 (마지막 날)</label><input id="fExpiry" type="date" value="${esc(g.expiry)}"></div>
      <div class="field"><label>종류</label><div class="seg" id="fType"><button type="button" data-type="item" aria-pressed="${g.type!=="cash"}">상품 교환권</button><button type="button" data-type="cash" aria-pressed="${g.type==="cash"}">금액권</button></div></div>
      <div class="field" id="amountWrap" ${g.type==="cash"?"":"hidden"}><label for="fAmount">액면 금액 (원)</label><input id="fAmount" inputmode="numeric" value="${esc(g.amount)}" placeholder="예: 30000"></div>
      <div class="field"><label for="fMemo">메모</label><textarea id="fMemo" placeholder="예: 엄마가 보내줌, 강남점 사용 불가">${esc(g.memo)}</textarea></div>
      <div class="row"><button type="submit" class="btn primary">저장</button></div>
    </form>`, sheet => {
      sheet.querySelector("#fType").addEventListener("click", e => { const b=e.target.closest("button"); if(b) setType(b.dataset.type); });
      sheet.querySelector("#form").addEventListener("submit", async e => {
        e.preventDefault();
        const type = sheet.querySelector('#fType [aria-pressed="true"]').dataset.type;
        const out = { id:g.id, brand:$("#fBrand").value.trim(), name:$("#fName").value.trim(), barcode:$("#fBarcode").value.replace(/\s/g,""),
          expiry:$("#fExpiry").value, type, amount: type==="cash" ? Number(String($("#fAmount").value).replace(/[^\d]/g,""))||0 : null,
          memo:$("#fMemo").value.trim(), used:!!g.used, history:g.history||[], imgHash:g.imgHash||"", auto:!!g.auto, needsReview:false, createdAt:g.createdAt||Date.now(), updatedAt:Date.now() };
        if(!out.brand && !out.name){ toast("교환처나 상품명 중 하나는 입력해 주세요."); return; }
        try{
          if(g._img){ await DB.putImg(out.id, g._img); imgCache.set(out.id, g._img); }
          await DB.put(out); await reload();
          toast(isNew?"서랍에 넣었어요":"수정했어요");
          if(isNew){ ui.tab="avail"; closeSheet(); } else openDetail(out.id);
          scheduleAlerts();
        }catch(err){ toast("저장하지 못했어요. 휴대폰 저장 공간을 확인해 주세요."); }
      });
    });
}

/* ---------- detail ---------- */
function barcodeSvg(code, h){
  if(!code || typeof JsBarcode!=="function") return "";
  const svg = document.createElementNS("http://www.w3.org/2000/svg","svg");
  try{ JsBarcode(svg, code, {format:"CODE128", displayValue:false, margin:0, height:h||80, width:2, background:"#FFFFFF", lineColor:"#000000"}); svg.setAttribute("preserveAspectRatio","none"); return svg.outerHTML; }catch(e){ return ""; }
}
const spaced = c => c.replace(/(\d{4})(?=\d)/g,"$1 ");

async function openDetail(id){
  const g = items.find(x=>x.id===id); if(!g) return;
  const st = statusOf(g), n = daysLeft(g.expiry), bal = balanceOf(g);
  const pill = st==="used" ? '<span class="pill off">사용 완료</span>' : st==="expired" ? '<span class="pill off">기간 만료</span>' : `<span class="pill ${urgency(g)}">${ddayText(n)}${n===0?" · 오늘까지":""}</span>`;
  openSheet(`${head(esc(g.name||"상품명 미입력"))}
    ${g.needsReview?`<div class="ai err"><span>자동 인식으로 등록했지만 ${[!g.brand&&"교환처",!g.barcode&&"쿠폰번호",!g.expiry&&"유효기간"].filter(Boolean).join("·")||"일부 정보"}를 확실히 읽지 못했어요. 아래 원본 이미지와 비교해 주세요.</span></div><div class="row" style="margin-bottom:12px"><button class="btn primary" data-act="ok">맞아요</button><button class="btn" data-act="edit">고치기</button></div>`:""}
    <div class="d-meta">${pill}<span class="pill off">${esc(g.brand||"교환처 미입력")}</span>${g.type==="cash"?'<span class="pill off">금액권</span>':""}</div>
    ${g.barcode?`<div class="barcode-card">${barcodeSvg(g.barcode)}<div class="barcode-num">${esc(spaced(g.barcode))}</div></div>
    <div class="row" style="margin-top:10px"><button class="btn" data-act="full">바코드 크게 보기</button><button class="btn" data-act="copy">번호 복사</button></div>`:`<p class="note">쿠폰번호가 없어요. 수정에서 입력하면 바코드를 만들어 드려요. 아래 원본 이미지로도 사용할 수 있어요.</p>`}
    <dl class="kv"><dt>유효기간</dt><dd>${g.expiry?esc(fmtDate(g.expiry))+"까지":"확인 필요"}</dd>
      ${g.type==="cash"?`<dt>액면가</dt><dd>${won(g.amount)}</dd><dt>남은 금액</dt><dd><b style="color:var(--accent)">${won(bal)}</b></dd>`:""}
      ${g.memo?`<dt>메모</dt><dd>${esc(g.memo)}</dd>`:""}</dl>
    ${g.type==="cash" && st!=="used"?`<form id="useForm" class="row" style="margin-bottom:12px"><div class="field" style="flex:1 1 150px;margin:0"><label for="useAmt">이번에 쓴 금액</label><input id="useAmt" inputmode="numeric" placeholder="예: 4500"></div><button class="btn primary" style="flex:0 0 auto;align-self:flex-end">기록</button></form>`:""}
    ${(g.history||[]).length?`<ul class="hist">${g.history.map(h=>`<li><span>${esc(fmtDate(h.date))}</span><span>-${won(h.amount)}</span></li>`).join("")}</ul>`:""}
    <div class="row">${st==="used"?`<button class="btn" data-act="unuse">사용 전으로 되돌리기</button>`:`<button class="btn primary" data-act="use">사용 완료로 표시</button>`}</div>
    <div class="row" style="margin-top:8px"><button class="btn" data-act="share">가족·친구에게 보내기</button>${g.expiry && st==="avail"?`<button class="btn" data-act="ics">캘린더에 알림 추가</button>`:""}</div>
    <div class="row" style="margin-top:8px"><button class="btn" data-act="edit">수정</button><button class="btn danger" data-act="askdel">삭제</button></div>
    <div id="confirmBox"></div>
    <div class="d-img" id="dImg"></div>`, sheet => {
      sheet.dataset.id = id;
      const f = sheet.querySelector("#useForm");
      f && f.addEventListener("submit", async e => {
        e.preventDefault(); const v = Number($("#useAmt").value.replace(/[^\d]/g,""));
        if(!v){ toast("쓴 금액을 입력해 주세요."); return; }
        const hist = (g.history||[]).concat({date:isoToday(), amount:Math.min(v, bal)});
        const left = (Number(g.amount)||0) - hist.reduce((a,h)=>a+h.amount,0);
        await save({...g, history:hist, used:left<=0, updatedAt:Date.now()}, left<=0?"잔액을 모두 써서 사용 완료로 옮겼어요":"사용 금액을 기록했어요"); openDetail(id);
      });
    });
  const showImg = d => { const el=$("#dImg"); if(el && d) el.innerHTML=`<img src="${d}" alt="원본 기프티콘 이미지">`; };
  if(imgCache.get(id)) showImg(imgCache.get(id)); else { try{ const d=await DB.getImg(id); if(d){ imgCache.set(id,d); showImg(d);} }catch(e){} }
}
async function save(g, msg){ try{ await DB.put(g); await reload(); if(msg) toast(msg); scheduleAlerts(); }catch(e){ toast("저장하지 못했어요. 다시 시도해 주세요."); } }

let wake=null;
async function fullBarcode(g){
  const el = document.createElement("div"); el.className="full"; el.id="full";
  el.innerHTML = `<div class="ft">${esc(g.brand)} · ${esc(g.name)}</div><div class="fb">${barcodeSvg(g.barcode,140)}<div class="barcode-num">${esc(spaced(g.barcode))}</div></div><div class="hint">화면을 누르면 닫혀요${NATIVE?" · 밝기를 최대로 올렸어요":" · 화면 밝기를 최대로 올리면 잘 찍혀요"}</div>`;
  el.addEventListener("click", () => { el.remove(); try{ wake && wake.release(); }catch(e){} wake=null; if(NATIVE) NATIVE.barcodeMode(false); });
  document.body.appendChild(el);
  if(NATIVE){ NATIVE.barcodeMode(true); return; }
  try{ wake = await navigator.wakeLock.request("screen"); }catch(e){}
}

async function saveFile(name, blob){
  if(NATIVE){ const b64 = await new Promise(r => { const fr = new FileReader(); fr.onload = () => r(String(fr.result).split(",")[1]); fr.readAsDataURL(blob); }); NATIVE.saveFile(name, blob.type || "application/octet-stream", b64); return; }
  const a = document.createElement("a"); a.href = URL.createObjectURL(blob); a.download = name;
  document.body.appendChild(a); a.click(); setTimeout(()=>{ URL.revokeObjectURL(a.href); a.remove(); }, 2000);
}
function icsFor(g){
  const [y,m,d] = g.expiry.split("-");
  const next = new Date(+y, +m-1, +d+1);
  const dt2 = `${next.getFullYear()}${String(next.getMonth()+1).padStart(2,"0")}${String(next.getDate()).padStart(2,"0")}`;
  const t = ((g.brand?g.brand+" ":"")+(g.name||"기프티콘")+" 만료일").replace(/[,;\\]/g," ");
  return ["BEGIN:VCALENDAR","VERSION:2.0","PRODID:-//coupon-drawer//KO","BEGIN:VEVENT","UID:"+g.id+"@coupon-drawer",
    "DTSTAMP:"+new Date().toISOString().replace(/[-:]/g,"").slice(0,15)+"Z","DTSTART;VALUE=DATE:"+y+m+d,"DTEND;VALUE=DATE:"+dt2,
    "SUMMARY:"+t,"DESCRIPTION:쿠폰번호 "+(g.barcode||"-"),
    "BEGIN:VALARM","TRIGGER:-P3D","ACTION:DISPLAY","DESCRIPTION:3일 뒤 만료","END:VALARM",
    "BEGIN:VALARM","TRIGGER:PT9H","ACTION:DISPLAY","DESCRIPTION:오늘 만료","END:VALARM","END:VEVENT","END:VCALENDAR"].join("\r\n");
}
async function shareCoupon(g){
  const text = `[${g.brand||"기프티콘"}] ${g.name||""}\n유효기간 ${fmtDate(g.expiry)}까지${g.barcode?`\n쿠폰번호 ${spaced(g.barcode)}`:""}`;
  if(NATIVE){ let img = imgCache.get(g.id); try{ img = img || await DB.getImg(g.id); }catch(e){} NATIVE.share(text, img ? img.split(",")[1] : ""); return; }
  try{
    let img = imgCache.get(g.id) || await DB.getImg(g.id);
    if(img && navigator.canShare){
      const blob = await (await fetch(img)).blob();
      const file = new File([blob], `${g.brand||"coupon"}.jpg`, {type:"image/jpeg"});
      if(navigator.canShare({files:[file]})){ await navigator.share({files:[file], text}); return; }
    }
    if(navigator.share){ await navigator.share({text}); return; }
  }catch(e){ if(e && e.name==="AbortError") return; }
  try{ await navigator.clipboard.writeText(text); toast("쿠폰 정보를 복사했어요. 카톡에 붙여넣으세요."); }catch(e){ toast("이 브라우저에서는 공유를 쓸 수 없어요."); }
}

/* ---------- alerts ---------- */
async function alertsOn(){ try{ return (await DB.getMeta("alerts"))===true; }catch(e){ return false; } }
async function scheduleAlerts(){
  if(!(await alertsOn())) return;
  try{
    const reg = await navigator.serviceWorker?.ready;
    if(reg && "periodicSync" in reg){ try{ await reg.periodicSync.register("expiry-check",{minInterval: 12*60*60*1000}); }catch(e){} }
    if(reg) reg.active?.postMessage({type:"check-expiry"});
  }catch(e){}
}
async function toggleAlerts(on){
  if(on){
    if(!("Notification" in window)){ toast("이 브라우저는 알림을 지원하지 않아요. 캘린더 알림을 써 주세요."); return false; }
    const p = await Notification.requestPermission();
    if(p!=="granted"){ toast("알림이 차단돼 있어요. 휴대폰 설정에서 알림을 허용해 주세요."); return false; }
    await DB.setMeta("alerts", true); scheduleAlerts(); toast("만료 3일 전·당일에 알려 드릴게요"); return true;
  }
  await DB.setMeta("alerts", false); toast("만료 알림을 껐어요"); return false;
}

/* ---------- settings / backup ---------- */
async function openSettings(){
  if(NATIVE) return openNativeSettings();
  const on = await alertsOn();
  const isIOS = /iphone|ipad|ipod/i.test(navigator.userAgent);
  openSheet(`${head("설정 · 백업")}
    <div class="switch"><span><b>만료 알림</b><small>만료 3일 전과 당일에 휴대폰 알림을 보내요.</small></span><button class="btn ${on?"primary":""}" data-act="alerts" data-on="${on}">${on?"켜짐":"꺼짐"}</button></div>
    <p class="note">${isIOS?"아이폰은 홈 화면에 설치한 뒤 앱을 열 때 알림이 와요. 확실하게 받으려면 쿠폰마다 '캘린더에 알림 추가'를 함께 써 주세요.":"안드로이드 크롬에서 홈 화면에 설치하면 앱을 열지 않아도 하루 한두 번 확인해서 알려 줘요. 휴대폰 절전 설정에 따라 늦을 수 있어요."}</p>
    <div class="sec">백업</div>
    <div class="store-line"><span class="dot local"></span><span>쿠폰은 이 휴대폰에만 저장돼요. 휴대폰을 바꾸거나 브라우저 데이터를 지우기 전에 백업 파일을 받아 두세요.</span></div>
    <div class="row"><button class="btn" data-act="export">백업 파일 받기</button><button class="btn" data-act="import">백업 불러오기</button></div>
    <div class="sec">정리</div>
    <p class="note">총 ${items.length}개 · 사용 완료 ${items.filter(g=>g.used).length}개 · 만료 ${items.filter(g=>statusOf(g)==="expired").length}개</p>
    <div class="row"><button class="btn danger" data-act="askclean" ${items.some(g=>statusOf(g)!=="avail")?"":"disabled"}>사용 완료·만료 쿠폰 정리</button></div>
    <div id="confirmBox"></div>
    <p class="note" style="margin-top:18px">쿠폰서랍 v1.2 · 사진 인식은 휴대폰 안에서 처리되고 어디에도 전송되지 않아요.</p>`);
}
function openNativeSettings(){
  const st = nStatus();
  openSheet(`${head("설정 · 백업")}
    <div class="switch"><span><b>새 쿠폰 자동 감지</b><small>휴대폰에 기프티콘 이미지가 저장되거나 사진을 찍으면 알아서 읽고 등록해요.</small></span><button class="btn ${st.autoDetect?"primary":""}" data-act="auto" data-on="${!!st.autoDetect}">${st.autoDetect?"켜짐":"꺼짐"}</button></div>
        ${!st.mediaPermission && st.autoDetect===false ? `<p class="note">사진 접근을 '모두 허용'해야 새 쿠폰을 찾을 수 있어요. '선택한 사진만'으로 두면 자동 감지가 동작하지 않아요.</p>`:""}
    <div class="row"><button class="btn" data-act="scan30" ${st.mediaPermission?"":"disabled"}>최근 30일 사진에서 쿠폰 찾기</button></div>
    <div class="sec">알림</div>
    <div class="switch"><span><b>만료 알림</b><small>만료 3일 전, 전날, 당일에 알려 드려요.</small></span><button class="btn ${st.alerts?"primary":""}" data-act="nalerts" data-on="${!!st.alerts}">${st.alerts?"켜짐":"꺼짐"}</button></div>
    ${st.notifications?"":`<p class="note">휴대폰 알림이 꺼져 있어요. <button class="btn" data-act="appsettings" style="height:34px;margin-left:6px">알림 허용하러 가기</button></p>`}
    <div class="sec">백업</div>
    <div class="store-line"><span class="dot local"></span><span>쿠폰은 이 휴대폰에만 저장돼요. 휴대폰을 바꾸기 전에 백업 파일을 드라이브나 카톡 '나와의 채팅'에 보관해 두세요.</span></div>
    <div class="row"><button class="btn" data-act="export">백업 파일 저장</button><button class="btn" data-act="import">백업 불러오기</button></div>
    <div class="sec">정리</div>
    <p class="note">총 ${items.length}개 · 사용 완료 ${items.filter(g=>g.used).length}개 · 만료 ${items.filter(g=>statusOf(g)==="expired").length}개</p>
    <div class="row"><button class="btn danger" data-act="askclean" ${items.some(g=>statusOf(g)!=="avail")?"":"disabled"}>사용 완료·만료 쿠폰 정리</button></div>
    <div id="confirmBox"></div>
    <p class="note" style="margin-top:18px">쿠폰서랍 앱 v${esc(st.version||"")} · 사진 인식은 휴대폰 안에서 처리되고 어디에도 전송되지 않아요.</p>`);
}
async function scanRecent(days){
  bar(`최근 ${days}일 사진에서 쿠폰을 찾는 중… 사진이 많으면 몇 분 걸려요`, 0.3);
  const r = await nativeCall("scanRecent", days);
  bar(null);
  if(r.error){ toast("사진 접근 권한이 필요해요."); return; }
  if(!r.count){ toast(`최근 ${days}일 사진에서 새 쿠폰을 찾지 못했어요`); return; }
  await window.__pullPending({});
}
async function onboardNative(){
  let seen = false; try{ seen = await DB.getMeta("onboarded"); }catch(e){}
  if(seen || nStatus().autoDetect) return;
  if($("#scrim")){ afterClose = onboardNative; return; }
  try{ await DB.setMeta("onboarded", true); }catch(e){}
  openSheet(`${head("쿠폰을 알아서 모아 드릴게요")}
    <p class="note" style="font-size:15px;color:var(--ink)">카톡에서 받은 기프티콘을 <b>저장</b>하거나, 쿠폰을 <b>캡처</b>하거나, 종이 쿠폰을 <b>사진으로 찍으면</b> 쿠폰서랍이 알아서 읽고 등록해요. 유효기간이 다가오면 알림도 보내요.</p>
    <p class="note">다음 화면에서 <b>사진 접근은 '모두 허용'</b>, <b>알림은 '허용'</b>을 눌러 주세요. 사진은 휴대폰 안에서만 읽고 어디에도 보내지 않아요.</p>
    <div class="row" style="margin-top:8px"><button class="btn primary" data-act="auto-on">자동 감지 켜기</button><button class="btn" data-act="close">나중에</button></div>`);
}

async function exportBackup(){
  const out = [];
  for(const g of items){ let img=imgCache.get(g.id); if(!img){ try{ img=await DB.getImg(g.id);}catch(e){} } out.push({...g, image:img||null}); }
  const data = JSON.stringify({app:"coupon-drawer", version:1, exportedAt:new Date().toISOString(), items:out});
  const name = `쿠폰서랍-백업-${isoToday()}.json`;
  const file = new File([data], name, {type:"application/json"});
  if(NATIVE){ await saveFile(name, file); return; }
  try{ if(navigator.canShare && navigator.canShare({files:[file]}) && /android|iphone|ipad/i.test(navigator.userAgent)){ await navigator.share({files:[file], title:name}); return; } }catch(e){ if(e && e.name==="AbortError") return; }
  saveFile(name, file); toast("백업 파일을 저장했어요");
}
async function importBackup(file){
  try{
    const j = JSON.parse(await file.text()); const arr = Array.isArray(j.items)?j.items:[];
    let n=0; for(const raw of arr){ if(!raw || !raw.id) continue; const {image, ...g} = raw; if(image){ await DB.putImg(g.id,image); imgCache.set(g.id,image);} await DB.put(g); n++; }
    await reload(); closeSheet(); toast(`${n}개를 불러왔어요`); scheduleAlerts();
  }catch(e){ toast("백업 파일을 읽지 못했어요. 쿠폰서랍에서 받은 .json 파일인지 확인해 주세요."); }
}

/* ---------- events ---------- */
document.addEventListener("click", async e => {
  const t = e.target.closest("[data-act],[data-open],[data-tab],[data-brand]"); if(!t) return;
  if(t.dataset.open && t.classList.contains("res")){ closeSheet(); }
  if(t.dataset.open){ openDetail(t.dataset.open); return; }
  if(t.dataset.tab){ ui.tab=t.dataset.tab; ui.brand=""; render(); return; }
  if(t.dataset.brand!==undefined && t.classList.contains("chip") && !t.dataset.act){ ui.brand=t.dataset.brand; render(); return; }
  const act = t.dataset.act, sheet = document.querySelector(".sheet"), id = sheet && sheet.dataset.id, g = id && items.find(x=>x.id===id);
  switch(act){
    case "add": $("#file").click(); break;
    case "close": closeSheet(); break;
    case "full": g && fullBarcode(g); break;
    case "copy": if(NATIVE){ NATIVE.copy(g.barcode); toast("쿠폰번호를 복사했어요"); break; } try{ await navigator.clipboard.writeText(g.barcode); toast("쿠폰번호를 복사했어요"); }catch(err){ const r=document.createRange(); r.selectNodeContents(document.querySelector(".sheet .barcode-num")); const s=getSelection(); s.removeAllRanges(); s.addRange(r); toast("번호를 선택했어요. 길게 눌러 복사하세요"); } break;
    case "use": await save({...g, used:true, usedAt:Date.now(), updatedAt:Date.now()}, "사용 완료로 옮겼어요"); closeSheet(); break;
    case "unuse": await save({...g, used:false, updatedAt:Date.now()}, "사용 가능으로 되돌렸어요"); openDetail(id); break;
    case "edit": editForm(g, false); break;
    case "ok": await save({...g, needsReview:false, updatedAt:Date.now()}, "확인했어요"); openDetail(id); break;
    case "review": ui.review = !ui.review; render(); break;
    case "camera": $("#camera").click(); break;
    case "share": shareCoupon(g); break;
    case "ics": if(NATIVE){ NATIVE.addCalendar(`${g.brand?g.brand+" ":""}${g.name||"기프티콘"} 만료일`, g.expiry, g.barcode?`쿠폰번호 ${g.barcode}`:""); break; } saveFile(`${g.brand||"쿠폰"}-만료알림.ics`, new Blob([icsFor(g)],{type:"text/calendar"})); toast("받은 파일을 열어 캘린더에 추가하세요"); break;
    case "askdel": $("#confirmBox").innerHTML = `<div class="confirm"><p>이 쿠폰을 서랍에서 지울까요? 되돌릴 수 없어요.</p><div class="row"><button class="btn danger" data-act="del">삭제</button><button class="btn" data-act="nodel">취소</button></div></div>`; break;
    case "nodel": $("#confirmBox").innerHTML=""; break;
    case "del": try{ await DB.del(id); imgCache.delete(id); await reload(); toast("삭제했어요"); }catch(err){ toast("삭제하지 못했어요."); } closeSheet(); break;
    case "alerts": { const now = await toggleAlerts(t.dataset.on!=="true"); t.dataset.on=String(now); t.textContent=now?"켜짐":"꺼짐"; t.classList.toggle("primary", now); break; }
    case "export": exportBackup(); break;
    case "auto": case "auto-on": {
      const want = act==="auto-on" ? true : t.dataset.on!=="true";
      const st = await nativeCall("setAutoDetect", want);
      if(want && !st.mediaPermission){ toast("사진 접근을 '모두 허용'해야 자동 감지가 동작해요"); if(act==="auto") openNativeSettings(); break; }
      toast(want ? "자동 감지를 켰어요. 새 쿠폰 이미지가 생기면 알아서 등록해요" : "자동 감지를 껐어요");
      if(act==="auto-on"){ closeSheet(); setTimeout(()=>{ openSheet(`${head("예전에 받은 쿠폰도 찾아볼까요?")}<p class="note" style="font-size:15px;color:var(--ink)">최근 30일 동안 휴대폰에 저장된 사진에서 기프티콘을 찾아 한꺼번에 등록해요.</p><div class="row"><button class="btn primary" data-act="scan30">찾아보기</button><button class="btn" data-act="close">괜찮아요</button></div>`); }, 300); }
      else openNativeSettings();
      break; }
    case "scan30": closeSheet(); scanRecent(30); break;
    case "nalerts": { const on = t.dataset.on!=="true"; NATIVE.setAlerts(on); toast(on?"만료 알림을 켰어요":"만료 알림을 껐어요"); openNativeSettings(); break; }
    case "appsettings": NATIVE.openAppSettings(); break;
    case "import": $("#importFile").click(); break;
    case "askclean": $("#confirmBox").innerHTML = `<div class="confirm"><p>사용 완료·만료된 쿠폰 ${items.filter(x=>statusOf(x)!=="avail").length}개를 지울까요?</p><div class="row"><button class="btn danger" data-act="clean">모두 삭제</button><button class="btn" data-act="nodel">취소</button></div></div>`; break;
    case "clean": for(const x of items.filter(x=>statusOf(x)!=="avail")){ try{ await DB.del(x.id); imgCache.delete(x.id);}catch(err){} } await reload(); closeSheet(); toast("정리했어요"); break;
  }
});
$("#fab").addEventListener("click", () => $("#file").click());
$("#fabCam").addEventListener("click", () => $("#camera").click());
$("#btnSettings").addEventListener("click", openSettings);
$("#camera").addEventListener("change", e => { onFiles(e.target.files); e.target.value=""; });
$("#file").addEventListener("change", e => { onFiles(e.target.files); e.target.value=""; });
$("#importFile").addEventListener("change", e => { const f=e.target.files[0]; if(f) importBackup(f); e.target.value=""; });
$("#q").addEventListener("input", e => { ui.q=e.target.value.trim(); render(); });
document.addEventListener("keydown", e => { if(e.key==="Escape"){ const f=$("#full"); if(f) f.click(); else if($("#scrim")) closeSheet(); } });
document.addEventListener("visibilitychange", () => { if(!document.hidden){ render(); if(NATIVE) window.__pullPending(); else scheduleAlerts(); } });
// paste a screenshot directly (desktop)
document.addEventListener("paste", e => { const fs=[...(e.clipboardData?.files||[])].filter(f=>f.type.startsWith("image/")); if(fs.length){ e.preventDefault(); onFiles(fs); } });

/* ---------- install prompt ---------- */
let deferred = null;
const standalone = matchMedia("(display-mode: standalone)").matches || navigator.standalone;
const dismissed = () => { try{ return localStorage.getItem("installDismissed")==="1"; }catch(e){ return false; } };
if(!NATIVE) window.addEventListener("beforeinstallprompt", e => { e.preventDefault(); deferred = e; if(!dismissed()){ $("#installText").textContent="홈 화면에 설치하면 앱처럼 쓸 수 있어요."; $("#installBtn").hidden=false; $("#installBar").hidden=false; } });
if(!NATIVE && !standalone && /iphone|ipad|ipod/i.test(navigator.userAgent) && !dismissed()){
  $("#installText").textContent = "사파리 아래 공유 버튼(□↑) → '홈 화면에 추가'를 누르면 앱으로 설치돼요.";
  $("#installBtn").hidden = true; $("#installBar").hidden = false;
}
$("#installBtn").addEventListener("click", async () => { if(!deferred) return; deferred.prompt(); await deferred.userChoice.catch(()=>{}); deferred=null; $("#installBar").hidden=true; });
$("#installClose").addEventListener("click", () => { $("#installBar").hidden=true; try{ localStorage.setItem("installDismissed","1"); }catch(e){} });
window.addEventListener("appinstalled", () => { $("#installBar").hidden=true; toast("설치했어요. 홈 화면에서 쿠폰서랍을 여세요."); });

/* ---------- service worker & shared images ---------- */
async function takeShared(){
  if(!/[?&]shared=1/.test(location.search)) return;
  history.replaceState(null, "", location.pathname);
  try{
    const cache = await caches.open("share-inbox");
    const keys = await cache.keys(); const files = [];
    for(const k of keys){ const r = await cache.match(k); const b = await r.blob(); files.push(new File([b], "shared.jpg", {type:b.type||"image/jpeg"})); await cache.delete(k); }
    if(files.length) onFiles(files);
  }catch(e){}
}
if(!NATIVE && "serviceWorker" in navigator){
  navigator.serviceWorker.register("sw.js").then(() => scheduleAlerts()).catch(()=>{});
}

render();
reload().then(async () => { if(NATIVE){ await window.__pullPending(); onboardNative(); } else takeShared(); });
})();
