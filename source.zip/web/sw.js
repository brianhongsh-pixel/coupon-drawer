/* 쿠폰서랍 service worker: offline cache, shared-image inbox, expiry alerts */
const VERSION = "v1.2.0";
const SHELL = "shell-" + VERSION;
const LIBS = "libs-" + VERSION;
const SHELL_FILES = ["./", "index.html", "app.js", "manifest.webmanifest", "vendor/JsBarcode.all.min.js",
  "icons/icon-192.png", "icons/icon-512.png", "icons/maskable-512.png", "icons/apple-touch-icon.png", "icons/favicon-32.png"];

self.addEventListener("install", e => {
  e.waitUntil(caches.open(SHELL).then(c => c.addAll(SHELL_FILES)).then(() => self.skipWaiting()));
});
self.addEventListener("activate", e => {
  e.waitUntil((async () => {
    for (const k of await caches.keys()) if (k !== SHELL && k !== LIBS && k !== "share-inbox") await caches.delete(k);
    await self.clients.claim();
  })());
});

self.addEventListener("fetch", e => {
  const url = new URL(e.request.url);
  if (url.origin !== location.origin) return;
  // Android share sheet → 쿠폰서랍
  if (e.request.method === "POST" && url.pathname.endsWith("/share-target")) {
    e.respondWith((async () => {
      const form = await e.request.formData();
      const cache = await caches.open("share-inbox");
      let i = 0;
      for (const f of form.getAll("images")) {
        if (f && f.size) await cache.put(new Request("./inbox/" + Date.now() + "-" + (i++)), new Response(f, { headers: { "content-type": f.type || "image/jpeg" } }));
      }
      return Response.redirect(new URL("./?shared=1", self.registration.scope).href, 303);
    })());
    return;
  }
  if (e.request.method !== "GET") return;
  // big OCR files: cache on first use, then serve offline
  if (url.pathname.includes("/vendor/")) {
    e.respondWith(caches.open(LIBS).then(async c => {
      const hit = await c.match(e.request) || await caches.match(e.request);
      if (hit) return hit;
      const res = await fetch(e.request);
      if (res.ok) c.put(e.request, res.clone());
      return res;
    }));
    return;
  }
  // app shell: network first (to pick up updates), fall back to cache offline
  e.respondWith(fetch(e.request).then(res => {
    if (res.ok) caches.open(SHELL).then(c => c.put(e.request, res.clone()));
    return res;
  }).catch(async () => (await caches.match(e.request, { ignoreSearch: true })) || caches.match("index.html")));
});

/* ---------- expiry alerts ---------- */
function openDB() {
  return new Promise((res, rej) => {
    const r = indexedDB.open("coupon-drawer", 1);
    r.onupgradeneeded = () => { r.result.createObjectStore("items", { keyPath: "id" }); r.result.createObjectStore("imgs"); r.result.createObjectStore("meta"); };
    r.onsuccess = () => res(r.result); r.onerror = () => rej(r.error);
  });
}
function req(store, mode, fn) {
  return openDB().then(db => new Promise((res, rej) => {
    const t = db.transaction(store, mode); const out = fn(t.objectStore(store));
    t.oncomplete = () => res(out && out.result); t.onerror = () => rej(t.error);
  }));
}
function daysLeft(exp) {
  if (!exp) return null;
  const [y, m, d] = exp.split("-").map(Number);
  const n = new Date(); const today = new Date(n.getFullYear(), n.getMonth(), n.getDate()).getTime();
  return Math.round((new Date(y, m - 1, d).getTime() - today) / 86400000);
}
async function checkExpiry() {
  try {
    if ((await req("meta", "readonly", s => s.get("alerts"))) !== true) return;
    if (self.Notification && Notification.permission !== "granted") return;
    const items = (await req("items", "readonly", s => s.getAll())) || [];
    const sent = (await req("meta", "readonly", s => s.get("sent"))) || {};
    const n0 = new Date(); const today = `${n0.getFullYear()}-${n0.getMonth() + 1}-${n0.getDate()}`;
    for (const g of items) {
      if (g.used) continue;
      const n = daysLeft(g.expiry);
      if (n === null || n < 0 || (n !== 0 && n !== 1 && n !== 3)) continue;
      const key = g.id + ":" + n;
      if (sent[key]) continue;
      const when = n === 0 ? "오늘 만료돼요" : n === 1 ? "내일 만료돼요" : "3일 뒤 만료돼요";
      await self.registration.showNotification(`${g.brand || "기프티콘"} ${when}`, {
        body: `${g.name || ""} · ${g.expiry.replace(/-/g, ".")}까지`,
        icon: "icons/icon-192.png", badge: "icons/icon-192.png", tag: key, data: { id: g.id }
      });
      sent[key] = today;
    }
    await req("meta", "readwrite", s => s.put(sent, "sent"));
  } catch (e) {}
}
self.addEventListener("periodicsync", e => { if (e.tag === "expiry-check") e.waitUntil(checkExpiry()); });
self.addEventListener("message", e => { if (e.data && e.data.type === "check-expiry") e.waitUntil(checkExpiry()); });
self.addEventListener("notificationclick", e => {
  e.notification.close();
  e.waitUntil((async () => {
    const all = await self.clients.matchAll({ type: "window", includeUncontrolled: true });
    if (all.length) return all[0].focus();
    return self.clients.openWindow("./");
  })());
});
